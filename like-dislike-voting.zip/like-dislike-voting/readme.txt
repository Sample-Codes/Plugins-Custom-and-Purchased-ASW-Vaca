=== Like DisLike Voting ===
Contributors: Wasiul Alam Biswas
Donate link: http://portfolio.wasiul.com/product/like-dislike-voting-pro/
Tags: is this aricle helpful,yes-no,yes no rating, was this helpful, articlerating, tricks voting, content voting,Like , Dislike ,Unlike, Rating,Voting, Contest,Responsive,Like Rating,Dislike Rating
Requires at least: 3.3
Tested up to: 4.4
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://portfolio.wasiul.com/licenses/

"Is this article helpful?" Simple Responsive Like Dislike Button for rating system of your content.

== Description ==
Get like-dislike rating for your content. You can use the plugin to allow your user for rating as Like or Dislike to your content. 

It also counts and shows number of Like and Dislike hit. In dashboard you will find plugin option for placement of Like-Dislike button and also you can control voting type. You can allow everyone to rate your content and You also can allow registered user only to rate your content. It has simple codes that never crash with other plugin/theme.


= Upgrade to Like Dislike Pro =
Pro version is quite different in visually and popularly. A question (Is this article/ post helpful?) with "Yes" "No" button which will count the like and dislike rating.

Pro version features:

* Rating Method	: Two Button Rating "Yes" "No"
* Rating Method	: Rating text- Is this article helpful?
* Rate count	: Instant rate count and show
* Permission	: Anyone can vote / rate
* Permission	: Only registered user
* Support	: Installation and customization of it
* Presentation	: Before post at right or left side
* Presentation	: After post at left or right side
* Contact	: http://portfolio.wasiul.com/product/like-dislike-voting-pro/
  
== Installation ==

1. Upload `plugin` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to control pannel and choose your settings

== Frequently asked questions ==



== Screenshots ==

1. Frontend sidebar column
2. admin widget column
3. Pro screenshot

== Changelog ==

= v.1.0.1 =
1. Bug fix for preventing vote again.


== Upgrade notice ==



== Arbitrary section 1 ==
