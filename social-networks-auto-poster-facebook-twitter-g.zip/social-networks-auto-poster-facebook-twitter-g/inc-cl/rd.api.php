<?php    
//## NextScripts Reddit Connection Class

$nxs_snapAPINts[] = array('code'=>'RD', 'lcode'=>'rd', 'name'=>'Reddit');

if (!class_exists("nxs_class_SNAP_RD")) { class nxs_class_SNAP_RD {
    
    var $ntCode = 'RD';
    var $ntLCode = 'rd';
    
    function doPost($options, $message){ if (!is_array($options)) return false; $out = array(); // return false;
      foreach ($options as $ii=>$ntOpts) $out[$ii] = $this->doPostToNT($ntOpts, $message);
      return $out;
    }     
    function doPostToNT($options, $message){ global $nxs_urlLen; $badOut = array('pgID'=>'', 'isPosted'=>0, 'pDate'=>date('Y-m-d H:i:s'), 'Error'=>'');
      //## Check settings
      if (!is_array($options)) { $badOut['Error'] = 'No Options'; return $badOut; }      
      if (!isset($options['rdUName']) || trim($options['rdUName'])=='' || !isset($options['rdPass']) || trim($options['rdPass'])=='') { $badOut['Error'] = 'No username/password Found'; return $badOut; }      
      //## Format Post
      if (!empty($message['pTitle'])) $title = $message['pTitle']; else $title = nxs_doFormatMsg($options['rdTitleFormat'], $message); $title = nsTrnc($title, 300);  
      if (!empty($message['pText'])) $text = $message['pText']; else $text = nxs_doFormatMsg($options['rdTextFormat'], $message);       
      //## Make Post            
      $pass = substr($options['rdPass'], 0, 5)=='n5g9a'?nsx_doDecode(substr($options['rdPass'], 5)):$options['rdPass'];   $uname = $options['rdUName'];
      
      $nt = new nxsAPI_RD(); $nt->debug = false; if (!empty($options['ck'])) $nt->ck = $options['ck']; $loginErr = $nt->connect($uname, $pass);      
      if (!$loginErr) { nxs_save_glbNtwrks('rd', $options['ii'], $nt->ck, 'ck'); $ret = $nt->post($text, $title, $options['rdSubReddit'], $options['postType']=='A'?$message['url']:''); } 
        else { $badOut['Error'] .= 'Something went wrong - '.print_r($loginErr, true); $ret = $badOut; }            
      return $ret;
    }      
}}
?>