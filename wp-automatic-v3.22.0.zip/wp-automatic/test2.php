<?php 

print_r(unserialize( file_get_contents('test.txt') ));
 
?>