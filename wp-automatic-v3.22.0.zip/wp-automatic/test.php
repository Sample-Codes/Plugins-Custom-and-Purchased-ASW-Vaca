<?php 

//wp-load
require_once('../../../wp-load.php');

require_once 'core.php';

$wpautomatic = new wp_automatic();
echo $wpautomatic->curl_file_exists('http://images.craigslist.org/00000_263iRPxjW1Y_600x450.jpg');



?>