=== Remove Admin Bar ===
Contributors: dnesscarkey
Tags: admin bar, admin, hide admin bar, remove admin bar from client, disable admin bar
Requires at least: 3.0
Tested up to: 4.5.3
Stable tag: 1.3

This plugin removes Admin Bar from user end.

== Description ==

This Plugin removes Admin Bar from user end.

Just Activate the plugin and you are ready to go.

<strong>Plugin you may like</strong>

* <a target="_blank" href="http://wordpress.org/plugins/email-checker/">Real Email Checker</a>
* <a target="_blank" href="http://wordpress.org/plugins/wp-masonry-layout/">WP Masonry Layout</a>
* <a target="_blank" href="http://wordpress.org/extend/plugins/use-any-font">Use Any Font</a>
* <a target="_blank" href="http://wordpress.org/extend/plugins/any-mobile-theme-switcher/">Any Mobile Theme Switcher</a>
* <a target="_blank" href="http://wordpress.org/extend/plugins/jquery-validation-for-contact-form-7/">Jquery Validation For Contact Form 7</a>
* <a target="_blank" href="http://wordpress.org/extend/plugins/add-tags-and-category-to-page/">Add Tags And Category To Page</a>
* <a target="_blank" href="http://wordpress.org/extend/plugins/block-specific-plugin-updates/">Block Specific Plugin Updates</a>
* <a target="_blank" href="http://wordpress.org/extend/plugins/featured-image-in-rss-feed/">Featured Image In RSS Feed</a>
* <a target="_blank" href="http://wordpress.org/extend/plugins/html-in-category-and-pages/">.html in category and page url</a>

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Does it also disable the bar in admin panel ? =

No, It only works for Front end.

== Screenshots ==

1. Admin Bar.

== Changelog ==

= 1.2 =
* Tested with 4.2.3

= 0.1 =
* First Release