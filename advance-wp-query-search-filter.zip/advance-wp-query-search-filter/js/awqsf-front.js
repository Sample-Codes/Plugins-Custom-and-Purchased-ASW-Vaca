jQuery(document).ready(function($) {
	 $('.checkall').click(function () {
	    $(this).closest('.awqsf_box').find('input:checkbox').attr('checked', this.checked);
         });

 

});
