<?php
add_action('admin_menu', 'sourceGuard_menu');

function sourceGuard_menu() {
	add_options_page('Source Guard', 'Source Guard', 'manage_options', 'sourceGuard', 'sourceGuard_cp');
}

function sourceGuard_cp(){

global $sourceGuard_settings;
?>
<div class="wrap">
<h2>Source Guard Settings</h2>


<?
$current_mode = $sourceGuard_settings['mode'];

$enabled_modules = array('html_obfuscator' => false, 'js_encoder' => false);

if(isset($_POST['submit'])){
	
	if(($_POST['html_obfuscator'] == 1) && ($_POST['js_encoder'] == 1)){
		
		$new_mode = '3';
	}
	else if($_POST['html_obfuscator'] == 1){
		
		$new_mode = '1';
	}
	else if($_POST['js_encoder'] == 1){
		
		$new_mode = '2';
	}
	else{
		
		$new_mode = '0';
	}
	
	
	if($fp = @fopen(plugin_dir_path(__FILE__).'settings.php', 'w')){
		
		$current_mode = $new_mode;
		
		fwrite($fp, "<?\n\$sourceGuard_settings = array('mode' => '".$current_mode."');\n?>");
		fclose($fp);
		
		echo '<div id="setting-error-settings_updated" class="updated settings-error"> <p><strong>Settings saved.</strong></p></div>';
	}
	else{
		
		echo '<div id="setting-error-settings_updated" class="error settings-error"> <p><strong>Settings cant be saved!</strong></p></div>';
	}
}

switch($current_mode){
	
	case '1';
		//html obfuscation
		
		$enabled_modules['html_obfuscator'] = true;
	break;
	case '2';
		//js encoding
		
		$enabled_modules['js_encoder'] = true;
	break;
	case '3';
		//html+js
		
		$enabled_modules['html_obfuscator'] = true;
		$enabled_modules['js_encoder'] = true;
	break;
}
?>


<form action="" method="POST">
<h3>Available modules</h3>

<table class="form-table">

<tr valign="top">
<th scope="row"><label>HTML obfuscation</label></th>
<td>
	
	<label><input name="html_obfuscator" type="radio" value="1" autocomplete="off"<?=($enabled_modules['html_obfuscator'])?' checked':'';?>>&nbsp; <span>Enabled</span></label>&nbsp;&nbsp;
	<label><input name="html_obfuscator" type="radio" value="0" autocomplete="off"<?=(!$enabled_modules['html_obfuscator'])?' checked':'';?>>&nbsp; <span>Disabled</span></label>
</td>
</tr>
<tr valign="top">
<th scope="row"><label>JavaScript encoding</label></th>
<td>
	
	<label><input name="js_encoder" type="radio" value="1" autocomplete="off"<?=($enabled_modules['js_encoder'])?' checked':'';?>>&nbsp; <span>Enabled</span></label>&nbsp;&nbsp;
	<label><input name="js_encoder" type="radio" value="0" autocomplete="off"<?=(!$enabled_modules['js_encoder'])?' checked':'';?>>&nbsp; <span>Disabled</span></label>
</td>
</tr>
</tr>
</table>

<p class="submit"><input name="submit" id="submit" class="button-primary" value="Save Changes" type="submit"></p>
</form>

</div>
<?
}
?>