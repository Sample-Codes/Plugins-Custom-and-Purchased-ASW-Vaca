<?php
/*
Plugin Name: Source Guard
Plugin URI: http://codecanyon.net/item/source-guard-website-source-encoderencryptor/2785785
Description: 
Author: Mateusz Mania
Version: 1.0
Author URI: http://codecanyon.net/user/MyNameIsMatthew?ref=MyNameIsMatthew
*/

include(plugin_dir_path(__FILE__).'settings.php');
include(plugin_dir_path(__FILE__).'lib/sourceGuard.class.php');
include(plugin_dir_path(__FILE__).'admin.php');

function onStart(){
	
	ob_start('outputHandler');
}

function outputHandler($c){
	
	global $sourceGuard_settings;

	if((in_array($sourceGuard_settings['mode'], array('1','2','3'))) && (!is_admin())){
		
		$sourceGuard = new sourceGuard();
		$r = $sourceGuard -> Run($c, $sourceGuard_settings['mode']);
	}
	else{
		
		$r = $c;
	}
	
	return $r;
}

add_action('wp_loaded', 'onStart', 1000);
?>