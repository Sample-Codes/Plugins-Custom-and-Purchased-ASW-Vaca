<?
$sourceGuard_settings = array('mode' => '1');
?>