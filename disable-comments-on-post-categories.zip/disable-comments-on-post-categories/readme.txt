=== Disable Comments on Post Categories ===
Contributors: a.ankit
Donate link: http://spoontalk.com
Tags: comments, disable, categories, disable on post categories, posts
Requires at least: 3.6
Tested up to: 4.0
Stable tag: trunk

As the name suggest, the plugin allows administrator to disable comments on specific post categories. 

== Description ==

This plugin allows administrators to disable comments on specific post categories.  

This is a very basic plugin developed for a particular use case. If you have any feature suggestions then pls use the forums. 


If you face any problem using the plugin please ask in the [Forums](http://wordpress.org/support/plugin/disable-comments-on-post-categories/).

Here is the link to [Documentation](http://spoontalk.com/wordpress/documentation-for-disable-comments-on-post-categories-plugin/).


== Frequently Asked Questions ==


== Is it Multisite Compatible? ==
NO, Not yet. However if enough users request it, I might add it at a later stage. 

== Screenshots ==
1. Settings-Screen 


== Changelog ==

= 0.9 =
* First Release, currently under beta.

= 0.91 =
* Changed a variable name.


== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. The plugin settings can be accessed via the 'Settings' menu in the administration area
