Plugin Name: DT hAtom WordPress Error Plugin

/*
Plugin Name: DT hAtom WordPress Error Plugin
Plugin URI: http://www.davidtiong.com/plugins/dt-hatom-error-removal-plugin
Description: A plugin to help remove hAtom errors from WordPress posts and pages, when testing with Google Rich Snippet Tool. Some of the settings may not work with certain themes and plugins. Please also note that some plugins can add additional hAtom markup to your pages, that cannot be corrected by this plugin.
Author: David Tiong
Author URI: http://www.davidtiong.com
Version: 1.1.5
License: GNU General Public License GPLv2
*/

Please consult the url http://www.davidtiong.com/plugins/dt-hatom-error-removal-plugin/
for the video tutorial on how to use this plugin, any future updates will be listed on this page also.
This plugin is a premium plugin, requiring purchase for download.
If you have any enquiries, please contact the author at http://www.davidtiong.com/contact/


Version 1.1.5 Settings suggestions:

There are 7 checkboxes to help you correct hAtom errors. 
Test using the rich snippet tool before and after activating a checkbox.
Make sure you save the settings page each time you make a change. 
The video tutorial at http://www.davidtiong.com/dt-hatom-error-removal-plugin/ demonstrates the procedure.

Information below explains what each setting does. For additional information about conditional tags:
http://codex.wordpress.org/Conditional_Tags


Checkbox 1: Add hAtom code to Posts- 
Select this to add hAtom fields to POSTS - targets is_single() conditional tag that is for any single post that is being displayed.
(This setting does not change your website's home page)

Checkbox 2: Add hAtom code to Pages-
Select this to add hAtom fields to STATIC PAGES - targets is_page() conditional tag that is for standard WordPress pages
(This setting does not change your website's home page)

Checkbox 3: Remove Hentry class from Home page-
Select this to remove hEntry class from HOME PAGE - targets is_front_page() conditional tag that is for your website's home/front page
This setting changes home pages that are set to display "static page" or "your latest posts".
(Very Important: only select one home page checkbox option at a time)

Checkbox 4: Add hAtom code to Archive Pages-
Select this to add hAtom fields to ARCHIVE PAGES - targets is_archive() conditional tag that is for when any type of Archive page is displayed
(Very Important: only select one archive page checkbox at a time)

Checkbox 5: Remove hentry class from Archive Pages-
Alternative ARCHIVE PAGE option - targets is_archive() conditional tag to remove hentry class from the archive pages
(Very Important: only select one archive page checkbox at a time)

Checkbox 6: Add hAtom code to Home Static Page-
Alternative HOME PAGE option - targets is_page() and is_front_page() to add hAtom fields to a STATIC FRONT PAGE
(Very Important: only select one home page checkbox option at a time)

Checkbox 7: Add hAtom code to Home Latest Posts Page-
Alternative HOME PAGE option, - targets is_home() to add hAtom fields to LATEST POSTS DISPLAY HOME PAGE
(Very Important: only select one home page checkbox option at a time)

