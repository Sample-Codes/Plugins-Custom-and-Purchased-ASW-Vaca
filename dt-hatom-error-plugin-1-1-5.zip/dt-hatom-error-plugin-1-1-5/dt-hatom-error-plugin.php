<?php
/*
Plugin Name: DT hAtom WordPress Error Plugin
Plugin URI: http://www.davidtiong.com/plugins/dt-hatom-error-removal-plugin
Description: A plugin to help correct hAtom errors found on WordPress websites, when testing with Google Rich Snippet Tool. Some of the settings may not work with certain themes and plugins. Please also note that some plugins can add additional hAtom markup to your pages, that cannot be corrected by this plugin.
Author: David Tiong
Author URI: http://www.davidtiong.com
Version: 1.1.5
License: GNU General Public License GPLv2

*/

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

if (is_admin()) {
    add_action('admin_menu','dtherpt_add_admin_menu');
    add_action('admin_init','dtherpt_settings_init');
}

function dtherpt_add_admin_menu() {
    add_options_page(
            'DT hAtom Error Removal Plugin',
            'hAtom Error Removal',
            'manage_options',
            'dtherpt',
            'dtherpt_options_page' );
}

function dtherpt_settings_init() {
    register_setting('dtherpt_options','dtherpt_settings');
    
    add_settings_section(
            'dtherpt_plugin_section',
            __('Plugin Settings Options','wordpress'),
            'dtherpt_settings_section_callback',
            'dtherpt' );
    
    add_settings_field(
            'dtherpt_checkbox_field_0',
            __('Add hAtom code to Posts','wordpress'),
            'dtherpt_checkbox_field_0_callback',
            'dtherpt',
            'dtherpt_plugin_section',
            array('label_for' =>'dtherpt_checkbox_field_0')
            );
    add_settings_field(
            'dtherpt_checkbox_field_1',
            __('Add hAtom code to Pages','wordpress'),
            'dtherpt_checkbox_field_1_callback',
            'dtherpt',
            'dtherpt_plugin_section',
            array('label_for' =>'dtherpt_checkbox_field_1')
            );
    add_settings_field(
            'dtherpt_checkbox_field_2',
            __('Remove Hentry class from Home page','wordpress'),
            'dtherpt_checkbox_field_2_callback',
            'dtherpt',
            'dtherpt_plugin_section',
            array('label_for' =>'dtherpt_checkbox_field_2')
            );
    add_settings_field(
            'dtherpt_checkbox_field_3',
            __('Add hAtom code to Archive Pages','wordpress'),
            'dtherpt_checkbox_field_3_callback',
            'dtherpt',
            'dtherpt_plugin_section',
            array('label_for' =>'dtherpt_checkbox_field_3')
            );
    add_settings_field(
            'dtherpt_checkbox_field_4',
            __('Remove hentry class from Archive Pages','wordpress'),
            'dtherpt_checkbox_field_4_callback',
            'dtherpt',
            'dtherpt_plugin_section',
            array('label_for' =>'dtherpt_checkbox_field_4')
            );
    add_settings_field(
            'dtherpt_checkbox_field_5',
            __('Add hAtom code to Home Static Page','wordpress'),
            'dtherpt_checkbox_field_5_callback',
            'dtherpt',
            'dtherpt_plugin_section',
            array('label_for' =>'dtherpt_checkbox_field_5')
            );
    add_settings_field(
            'dtherpt_checkbox_field_6',
            __('Add hAtom code to Home Latest Posts Page','wordpress'),
            'dtherpt_checkbox_field_6_callback',
            'dtherpt',
            'dtherpt_plugin_section',
            array('label_for' =>'dtherpt_checkbox_field_6')
            );
}

function dtherpt_checkbox_field_0_callback() {
    $options = get_option('dtherpt_settings'); 
    if (!isset($options['dtherpt_checkbox_field_0'])){
    $options['dtherpt_checkbox_field_0'] = 0; }
    ?><input type="checkbox" id="dtherpt_checkbox_field_0" name="dtherpt_settings[dtherpt_checkbox_field_0]" <?php checked($options['dtherpt_checkbox_field_0'],1); ?> value="1">
Select this to add hAtom fields to posts &lpar;single posts only, not home page&rpar;
<?php 
}

function dtherpt_checkbox_field_1_callback() {
    $options = get_option('dtherpt_settings'); 
    if (!isset($options['dtherpt_checkbox_field_1'])){
    $options['dtherpt_checkbox_field_1'] = 0; }
    ?><input type="checkbox" id="dtherpt_checkbox_field_1" name="dtherpt_settings[dtherpt_checkbox_field_1]" <?php checked($options['dtherpt_checkbox_field_1'],1); ?> value="1">
Select this to add hAtom fields to pages &lpar;static pages only, not home page&rpar;
<?php 
}

function dtherpt_checkbox_field_2_callback() {
    $options = get_option('dtherpt_settings'); 
    if (!isset($options['dtherpt_checkbox_field_2'])){
    $options['dtherpt_checkbox_field_2'] = 0; }
    ?><input type="checkbox" id="dtherpt_checkbox_field_2" name="dtherpt_settings[dtherpt_checkbox_field_2]" <?php checked($options['dtherpt_checkbox_field_2'],1); ?> value="1">
Select this to remove hEntry class from homepage &lpar;read warning above&rpar;
<?php 
}

function dtherpt_checkbox_field_3_callback() {
    $options = get_option('dtherpt_settings'); 
    if (!isset($options['dtherpt_checkbox_field_3'])){
    $options['dtherpt_checkbox_field_3'] = 0; }
    ?><input type="checkbox" id="dtherpt_checkbox_field_3" name="dtherpt_settings[dtherpt_checkbox_field_3]" <?php checked($options['dtherpt_checkbox_field_3'],1); ?> value="1">
Select this to add hAtom fields to archive pages &lpar;works when your website uses archive templates&rpar;
<?php 
}

function dtherpt_checkbox_field_4_callback() {
    $options = get_option('dtherpt_settings'); 
    if (!isset($options['dtherpt_checkbox_field_4'])){
    $options['dtherpt_checkbox_field_4'] = 0; }
    ?><input type="checkbox" id="dtherpt_checkbox_field_4" name="dtherpt_settings[dtherpt_checkbox_field_4]" <?php checked($options['dtherpt_checkbox_field_4'],1); ?> value="1">
Alternative archive page option, uncheck other archive setting&lpar;removes hentry see warning above&rpar;
<?php 
}

function dtherpt_checkbox_field_5_callback() {
    $options = get_option('dtherpt_settings'); 
    if (!isset($options['dtherpt_checkbox_field_5'])){
    $options['dtherpt_checkbox_field_5'] = 0; }
    ?><input type="checkbox" id="dtherpt_checkbox_field_5" name="dtherpt_settings[dtherpt_checkbox_field_5]" <?php checked($options['dtherpt_checkbox_field_5'],1); ?> value="1">
Alternative home page option, uncheck other home page settings &lpar;adds hAtom fields to home page if static page displayed&rpar;
<?php 
}

function dtherpt_checkbox_field_6_callback() {
    $options = get_option('dtherpt_settings'); 
    if (!isset($options['dtherpt_checkbox_field_6'])){
    $options['dtherpt_checkbox_field_6'] = 0; }
    ?><input type="checkbox" id="dtherpt_checkbox_field_6" name="dtherpt_settings[dtherpt_checkbox_field_6]" <?php checked($options['dtherpt_checkbox_field_6'],1); ?> value="1">
Alternative home page option, uncheck other home page settings &lpar;adds hAtom fields to home page if latest posts displayed&rpar;
<?php 
}

function dtherpt_settings_section_callback() {
    echo __('Choose options by checking or unchecking boxes below, then Save Changes. <br/><strong>Read Important Notes: </strong><br/>Warning: Removing hEntry class from a page can affect some themes appearance. Untick setting and save to add hEntry back onto the page.<br/>Note: Archive pages do not always use the excerpt or the content for displaying snippet, if so then this setting will not work. ','wordpress' );
}

function dtherpt_options_page() {
    ?><div class="wrap"><h2>hAtom Error Removal Options</h2>
<form action="options.php" method="post">
<?php 
    settings_fields('dtherpt_options');
    do_settings_sections('dtherpt');
    submit_button(); ?>
</form></div><?php }

//add hatom data to posts
function add_mod_hatom_data_plugin($content) {
    $t = get_the_modified_time('F jS, Y');
    $author = get_the_author();
    $title = get_the_title();
    if(is_single() && is_main_query() && in_the_loop() && !is_front_page()) {
        $content .= '<div class="dtherpt"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>';
    }
    return $content;
    }

//add hatom data to pages, not home page
function add_mod_hatom_data_to_page($content) {
    $t = get_the_modified_time('F jS, Y');
    $author = get_the_author();
    $title = get_the_title();
    if(is_page() && is_main_query() && in_the_loop() && !is_front_page()) {
        $content .= '<div class="dtherpt"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>';
    }
    return $content;
    }

//remove hentry class from pages and home page
function remove_hentry_class_home($classes) {
    if (is_front_page()) {
        $classes = array_diff ($classes, array('hentry'));
    }
    return $classes;
}

//add hatom data to the_excerpt or the_content on category pages, and other archive pages
function add_mod_hatom_data_archives($content) {
    $t = get_the_modified_time('F jS, Y');
    $author = get_the_author();
    $title = get_the_title();
    if(is_archive() && in_the_loop()) {
        $content .= '<div class="dtherpt"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>';
    }
    return $content;
    }

//remove hentry class from archive pages
function remove_hentry_class_archive($classes) {
    if (is_archive()) {
        $classes = array_diff ($classes, array('hentry'));
    }
    return $classes;
}

//add hatom data to static front page
function add_hatom_data_static_front_page($content) {
    $t = get_the_modified_time('F jS, Y');
    $author = get_the_author();
    $title = get_the_title();
    if(is_page() && is_main_query() && in_the_loop() && is_front_page()) {
        $content .= '<div class="dtherpt"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>';
    }
    return $content;
    }
    
//add hatom data to the_excerpt or the_content on home latest posts page
function add_hatom_data_latest_posts_home($content) {
    $t = get_the_modified_time('F jS, Y');
    $author = get_the_author();
    $title = get_the_title();
    if(is_home() && in_the_loop()) {
        $content .= '<div class="dtherpt"><span class="entry-title">'.$title.'</span> was last modified: <span class="updated"> '.$t.'</span> by <span class="author vcard"><span class="fn">'.$author.'</span></span></div>';
    }
    return $content;
    }
    
//enqueue stylesheet
function dtherpt_styles() {
    wp_enqueue_style('dtherptstyles',plugins_url('hatom-style.css',__FILE__),array(),'1.0.1'); 
}
add_action('wp_enqueue_scripts','dtherpt_styles');

$dtherpt_options_checks = get_option('dtherpt_settings');

if (isset($dtherpt_options_checks['dtherpt_checkbox_field_0'])){
$mycheckbox0 = $dtherpt_options_checks['dtherpt_checkbox_field_0'];}
else { $mycheckbox0 = "0"; }
if ($mycheckbox0 === "1") {
    add_filter('the_content', 'add_mod_hatom_data_plugin');
}

if (isset($dtherpt_options_checks['dtherpt_checkbox_field_1'])){
$mycheckbox1 = $dtherpt_options_checks['dtherpt_checkbox_field_1'];}
else { $mycheckbox1 = "0"; }
if ($mycheckbox1 === "1") {
    add_filter('the_content', 'add_mod_hatom_data_to_page');
}

if (isset($dtherpt_options_checks['dtherpt_checkbox_field_2'])){
$mycheckbox2 = $dtherpt_options_checks['dtherpt_checkbox_field_2'];}
else { $mycheckbox2 = "0"; }
if ($mycheckbox2 === "1") {
    add_filter('post_class','remove_hentry_class_home');
}

if (isset($dtherpt_options_checks['dtherpt_checkbox_field_3'])){
$mycheckbox3 = $dtherpt_options_checks['dtherpt_checkbox_field_3'];}
else { $mycheckbox3 = "0"; }
if ($mycheckbox3 === "1") {
    add_filter('the_excerpt', 'add_mod_hatom_data_archives');
    add_filter('the_content', 'add_mod_hatom_data_archives');
}

if (isset($dtherpt_options_checks['dtherpt_checkbox_field_4'])){
$mycheckbox4 = $dtherpt_options_checks['dtherpt_checkbox_field_4'];}
else { $mycheckbox4 = "0"; }
if ($mycheckbox4 === "1") {
    add_filter('post_class','remove_hentry_class_archive');
}

if (isset($dtherpt_options_checks['dtherpt_checkbox_field_5'])){
$mycheckbox5 = $dtherpt_options_checks['dtherpt_checkbox_field_5'];}
else { $mycheckbox5 = "0"; }
if ($mycheckbox5 === "1") {
    add_filter('the_content','add_hatom_data_static_front_page');
}

if (isset($dtherpt_options_checks['dtherpt_checkbox_field_6'])){
$mycheckbox6 = $dtherpt_options_checks['dtherpt_checkbox_field_6'];}
else { $mycheckbox6 = "0"; }
if ($mycheckbox6 === "1") {
    add_filter('the_content','add_hatom_data_latest_posts_home');
    add_filter('the_excerpt','add_hatom_data_latest_posts_home');
}

function add_dtherpt_action_links ( $links ) {
 $mylinks = array(
 '<a href="' . admin_url( 'options-general.php?page=dtherpt' ) . '">Settings</a>',
 );
return array_merge( $links, $mylinks );
}
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'add_dtherpt_action_links' );

?>