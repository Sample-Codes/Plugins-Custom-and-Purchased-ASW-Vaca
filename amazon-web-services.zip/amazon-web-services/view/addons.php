<div class="aws-content aws-addons">
	<ul class="addons-list">
		<?php $this->render_addons(); ?>
	</ul>
</div>