<?php  
// Main Class
require_once 'core.php';

Class WpAutomaticFacebook extends wp_automatic{
	


	/**
	 * function : fb_get_post
	 */
	function fb_get_post($camp){
	
		//get page id
		$camp_general=unserialize(base64_decode($camp->camp_general));
		$camp_opt = unserialize ( $camp->camp_options );
	
		echo '<br>Processing FB page:'.$camp_general['cg_fb_page'];
	
	
		//getting access tocken
		$cg_fb_access = get_option('wp_automatic_fb_token','');
	
		if(trim($cg_fb_access ) == ''){
	
			echo '<br>Getting a FB access token..';
	
			$wp_automatic_fb_app = trim( get_option('wp_automatic_fb_app','') );
			$wp_automatic_fb_secret = trim( get_option('wp_automatic_fb_secret','') );
	
			if(trim($wp_automatic_fb_app) == '' || trim($wp_automatic_fb_secret) == ''){
				echo '<br>NO APP ID FOUND, PLEASE VISIT THE PLUGIN SETTING AND ADD THE FACEBOOK APP ID/SECRET';
				return false;
			}
	
			//get token
			//curl get
			$x='error';
			$url="https://graph.facebook.com/oauth/access_token?client_id=$wp_automatic_fb_app&client_secret=$wp_automatic_fb_secret&grant_type=client_credentials";
			curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
			curl_setopt($this->ch, CURLOPT_URL, trim($url));
	
			$exec=curl_exec($this->ch);
			$x=curl_error($this->ch);
	
			if(stristr($exec, 'access_token=')){
	
				//found
				echo '<br>Successfully got an access token';
				$acexplode = explode('=', $exec);
				$cg_fb_access = $acexplode[1];
	
				update_option('wp_automatic_fb_token', $cg_fb_access);
	
			}else{
	
				echo '<br>Can not find access token at content after requesting it'.$x.$exec;
				return false;
	
			}
	
	
		}
	
	
		// PAGE ID
		$cg_fb_page_id = get_post_meta($camp->camp_id,'cg_fb_page_id',1);
	
		//if a numeric id use it direclty
		$url= $camp_general['cg_fb_page'] ;
	
		if(is_numeric($url)){
			echo '<br>Numeric id added manually using it as the page id.';
			$cg_fb_page_id = trim($url);
		}
	
	
		//get page id if not still extracted
		if(trim($cg_fb_page_id) == ''){
			echo '<br>Extracting page id from original page link';
	
			//getting page name from url
				
				
			//curl get
			$x='error';
			$url= $camp_general['cg_fb_page'] ;
			curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
			curl_setopt($this->ch, CURLOPT_URL, trim($url));
			$exec=curl_exec($this->ch);
			$x  = curl_error($this->ch);
	
		 		
			if(stristr($exec, 'PageComposerPagelet_')){
	
				//extracting
				preg_match_all('{PageComposerPagelet_(\d*?)"}', $exec,$matches);
				$smatch =  $matches[1];
				$cg_fb_page_id = $smatch[0];
					
				if(trim($cg_fb_page_id) !=''){
					echo '<br>Successfully extracted entityID:'.$cg_fb_page_id;
					update_post_meta($camp->camp_id, 'cg_fb_page_id', $cg_fb_page_id);
				}else{
					echo '<br>Can not find numeric entityID';
				}
	
			}else{
	
				//entity_id if the fb page validation check
				if(stristr($exec, 'entity_id')){
					echo '<br>entity_id found getting id from it';
						
					preg_match_all('{entity_id":"(\d*?)"}', $exec,$matches);
					$smatch =  $matches[1];
					$cg_fb_page_id = $smatch[0];
	
					if(trim($cg_fb_page_id) !=''){
						echo '<br>Successfully extracted entityID:'.$cg_fb_page_id;
						update_post_meta($camp->camp_id, 'cg_fb_page_id', $cg_fb_page_id);
					}else{
						echo '<br>Can not find numeric entityID';
					}
						
						
						
				}else{
					echo '<br>entity_id does not exists either ';
					echo '<br>Can not find valid FB reply.';
				}
	
	
			}
	
		}
	
	
		//building feed
		if(  (trim($cg_fb_page_id) !='' ) &&  (trim($cg_fb_access) !='' )  ){
				
				
			$cg_fb_source = $camp_general['cg_fb_source'];
				
			if($cg_fb_source == 'group'){
	
				$cg_fb_page_feed = "https://graph.facebook.com/v2.5/$cg_fb_page_id/feed?access_token=$cg_fb_access&limit=100&fields=message,story,attachments,created_time,id,type,picture,link,name,description,from";
				$cg_fb_page_feed2 = "https://graph.facebook.com/v2.5/$cg_fb_page_id/feed?access_token=[token]";
				$cg_fb_page_feed2 = $cg_fb_page_feed;
				
			}else{
	
				$cg_fb_page_feed = "https://graph.facebook.com/v2.5/$cg_fb_page_id/posts?access_token=$cg_fb_access&limit=100&fields=message,story,attachments,created_time,id,type,picture,link,name,description,from";
				$cg_fb_page_feed2 = "https://graph.facebook.com/v2.5/$cg_fb_page_id/posts?access_token=[token]";
	
			}
				
				
			echo '<br>FB URL:'.$cg_fb_page_feed2;
				
			//load feed
			//curl get
			$x='error';
			$url=$cg_fb_page_feed;
			curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
			curl_setopt($this->ch, CURLOPT_URL, trim($url));
				
			//CACHE
			$saveCache = false;
				
			if(in_array('OPT_FB_CACHE', $camp_opt)){
	
				$temp = get_post_meta($camp->camp_id,'wp_automatic_cache',true);
				@$temp = base64_decode($temp);
	
				if(stristr($temp, '"data"')){
						
					echo '<br>Results loaded from the cache';
					$exec = $temp;
	
				}else{
					echo '<br>Cache found but not valid';
					$saveCache = true;
					$exec=curl_exec($this->ch);
				}
	
			}else{
				$exec=curl_exec($this->ch);
			}
	
			$x=curl_error($this->ch);
	
			if ( stristr($exec, '"data"') ){ // Checks that the object is created correctly
					
				//if save cache enbaled
				if($saveCache){
					echo '<br>Caching the results..';
					update_post_meta($camp->camp_id, 'wp_automatic_cache', base64_encode($exec));
				}
	
				$fb_json =json_decode($exec);
	
				$items = $fb_json->data;
					
					
				// Loop through each feed item and display each item as a hyperlink.
				$i = 0;
	
				echo ' items:'.count($items);
	
				foreach ( $items as $item ){
						
	
					// building the link
					$item_id = $item->id;
					$id_parts = explode('_', $item_id);
					$url = "https://www.facebook.com/{$id_parts[0]}/posts/{$id_parts[1]}";
						
					echo '<br>Link:'.$url ;
	
					//check if execluded link due to exact match does not exists
					if( $this->is_execluded($camp->camp_id, $url)){
						echo '<-- Execluded link';
						continue;
					}
						
					//check if old
					if(in_array('OPT_YT_DATE', $camp_opt)     ){
						if($this->is_link_old($camp->camp_id,  strtotime(  $item->created_time  ) )){
							echo '<--old post execluding...';
							continue;
						}
					}
						
					if (! $this->is_duplicate($url) ) {
						echo '<-- new link';
	
						/*
						 echo '<pre>';
						 print_r($item);
						 echo '</pre>';
						 */
							
						//hyperlinking
						if(isset($item->message) ){
	
							$item->message = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$0</a>', $item->message);
	
							//hyperlinking the message links
							if( isset($item->message) && trim($item->message) != '' ){
									
								//extracting  hashtags
								$item->message = preg_replace('/#(\w+)/u', ' <a href="https://www.facebook.com/hashtag/$1">#$1</a>', $item->message);
	
							}
								
						}else{
							$item->message = '';
						}
	
							
						$i ++;
						// posting content to emails
						$created_time  = $item->created_time;
	
	
	
	
						$created_time_parts = explode('+', $created_time);
						$created_time = $created_time_parts[0];
						$created_time = str_replace('T', ' ', $created_time);
	
						//utc convert
						$created_time = get_date_from_gmt($created_time);
							
						$wpdate = $date = $created_time;
	
	
					}else{
						echo '<-- duplicate in post <a href="'.get_edit_post_link($this->duplicate_id).'">#'.$this->duplicate_id.'</a>';
						continue;
	
					}
						
					//check if older than minimum date
					if($this->is_link_old($camp->camp_id,  strtotime($wpdate) )){
						echo '<--old post execluding...';
						continue;
					}
	
					//building content
					$type = $item->type;
					echo '<br>Item Type:'.$type;
						
					//type check
					if(in_array('OPT_FB_POST_FILTER', $camp_opt)){
	
						if( ! in_array('OPT_FB_POST_'.$type, $camp_opt)){
							echo '<-- Skip this type not selected ';
							continue;
						}
	
					}
						
					//buidling content
					$title = '';
					$content = '';
					
					 
					if($type == 'link'){
							
						$title = $item->name;
						
						$txtContent = $item->message;
						
						if(! in_array('OPT_FB_TXT_SKIP', $camp_opt)) $content = $item->message; 
						 
						$link = $item->link;
	
						if(trim($item->picture != '')){
							$content .= '<p><a href="'.$link.'"><img title="'.$title.'" src="'. $item->picture .'" /></a> </p>';
						}
							
						//link
						$content .= '<p><a href="'.$link.'">'.@$item->name.'</a></p>';
							
						if( trim($item->description) !=''){
								
							$txtContent.= $item->description;
							if(! in_array('OPT_FB_TXT_SKIP', $camp_opt)) $content.= $item->description;
							
						}
							
							
					}elseif($type == 'status'){
	
						if(! in_array('OPT_FB_TXT_SKIP', $camp_opt)) $content = $item->message;
						$txtContent = $item->message;
						
						//check attachment
						$attachment = $item->attachments->data[0];
	
						if(trim($attachment->type) != ''){
								
							$attach_img = $attachment->media->image->src;
								
							if( in_array('OPT_FB_IMG_LNK_DISABLE', $camp_opt) ){
								$content .= '<br><img class="wp_automatic_fb_img" title="'.$attachment->title.'" src="'. $attach_img .'" />';
							}else{
								$content .= '<br><a href="'.$link.'"><img class="wp_automatic_fb_img" title="'.$attachment->title.'" src="'. $attach_img .'" /></a>';
							}
							
						
						
						}
	
						//attachment description
						if($attachment->description != ''){
							$txtContent.= $item->description;
							if(! in_array('OPT_FB_TXT_SKIP', $camp_opt)) $content.= $item->description;
						}
	
						if(trim($content) == ''){
							echo '<-- skip status, no content';
							$this->link_execlude( $camp->camp_id, $url );
							continue;
						}
	
	
					}elseif($type == 'photo'){
	
						if(trim($item->message) != ''){
							
							$txtContent = $item->message;
							if(! in_array('OPT_FB_TXT_SKIP', $camp_opt)) $content = $item->message;
							
						}elseif( trim($item->description) =='' ){
								
							if(! in_array('OPT_FB_TXT_SKIP', $camp_opt))  $content = $item->story;
							$txtContent = $item->story;
						}
	
						$content.='<br>';
	
						$link = $item->link;
							
						$attachment_type = $item->attachments->data[0]->type;
	
						echo '<br>Attachment Type:'. $attachment_type;
	
						if($attachment_type == 'album'){
								
							$allImgs = $item->attachments->data[0]->subattachments->data ;
								
						}else{
							$allImgs = $item->attachments->data;
						}
	
						if(count($allImgs) > 0){
								
							foreach ($allImgs as $singleImage ){
								
								if( in_array('OPT_FB_IMG_LNK_DISABLE', $camp_opt) ){
									$content .= '<br><img class="wp_automatic_fb_img" title="'.$title.'" src="'. $singleImage->media->image->src .'" />';
								}else{
									$content .= '<br><a href="'.$link.'"><img class="wp_automatic_fb_img" title="'.$title.'" src="'. $singleImage->media->image->src .'" /></a>';
								}
								
							}
	
						}
	
						//description
						if(trim($item->description) !=''){
							$txtContent.= '<br>'.$item->description;
							if(! in_array('OPT_FB_TXT_SKIP', $camp_opt)) $content.= '<br>'.$item->description;
						}
	
	
							
					}elseif( $type == 'video'  ){
	
							
						$style='';
	
						if (in_array('OPT_FB_VID_IMG_HIDE', $camp_opt) ){
							$style = ' style="display:none" ';
						}
	
	
						$content = '<img '.$style.' title="'.$title.'" src="'. $item->attachments->data[0]->media->image->src .'" /></a><br>';
	
						if(trim($item->message) != ''){
							
							$txtContent .= $item->message;
							if(! in_array('OPT_FB_TXT_SKIP', $camp_opt)) $content .= $item->message;
							
						}
	
						$vidurl = $item->link;
	
	
						if( stristr($vidurl, '/videos/') ){
							$vi_parts = explode('/videos/', $vidurl);
							$vid_id = $vi_parts[1];
								
							$vid_id = str_replace('/', '', $vid_id);
								
							echo '<br>Found video id:'. $vid_id;
	
							$content.= '[fb_vid id="'.$vid_id.'"]';
						}elseif(stristr($vidurl, 'youtube.com')){
								
							$content.= '<br><br>[embed]'.$vidurl.'[/embed]';
								
						}
	
						$txtContent .= $item->description;
						if(! in_array('OPT_FB_TXT_SKIP', $camp_opt))  $content .= $item->description;
	
					}elseif($type == 'event' || $type == 'offer' || $type == ''){
						
						$content = '';
						if(! in_array('OPT_FB_TXT_SKIP', $camp_opt))  @$content = $item->message;
						@$txtContent = $item->message;
						 
						//check attachment
						$attachment = $item->attachments->data[0];
						
						if(trim($attachment->type) != ''){
						
							$attach_img = $attachment->media->image->src;
						
							if( in_array('OPT_FB_IMG_LNK_DISABLE', $camp_opt) ){
								$content .= '<br><img class="wp_automatic_fb_img" title="'.$attachment->title.'" src="'. $attach_img .'" />';
							}else{
								$content .= '<br><a href="'.$link.'"><img class="wp_automatic_fb_img" title="'.$attachment->title.'" src="'. $attach_img .'" /></a>';
							}
							
						}
						
						//attachment description
						if($attachment->description != ''){
						
							$txtContent.='<br>'.$attachment->description;
							if(! in_array('OPT_FB_TXT_SKIP', $camp_opt))  $content.='<br>'.$attachment->description;
						
						}
						
						if(trim($content) == ''){
							echo '<-- skip status, no content';
							$this->link_execlude( $camp->camp_id, $url );
							continue;
						}
						
					}
	
					//check if title exits or generate it
					if(trim($title) == '' && in_array('OPT_GENERATE_FB_TITLE', $camp_opt) ){
	
						echo '<br>No title generating...';
	
						$tempContent = strip_tags(strip_shortcodes($txtContent));
						$tempContent = preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '', $tempContent);
	
						// Chars count
						$charsCount = $camp_general['cg_fb_title_count'];
						if(! is_numeric($charsCount)) $charsCount = 80;
	
						if(function_exists('mb_substr')){
							$newTitle =  mb_substr($tempContent, 0,$charsCount) ;
						}else{
							$newTitle =  substr($tempContent, 0,$charsCount) ;
						}
							
						if(trim($newTitle) == ''){
							echo '<- did not appropriate title';
						}else{
								
							$title = $newTitle;
								
							if($title != $tempContent){
								$title.= '...';
							}
								
						}
	
					}
						
					 	
	
					if(trim($title) == '' && in_array('OPT_FB_TITLE_SKIP', $camp_opt)){
						echo '<-- No title skiping.';
						continue;
					}
						
						
					//remove referral suffix
					if( stristr($content, 'com/l.php') ){
	
						//extract links
						preg_match_all('{"http://l\.facebook\.com/l\.php\?u=(.*?)"}', $content,$matches);
	
						$founds = $matches[0];
						$links = $matches[1];
	
						$i=0;
						foreach ($founds as $found){
								
							$found = str_replace('"', '', $found);
							$link = $links[$i];
								
							$link_parts = explode('&h', $link);
							$link = $link_parts[0];
	
							$content = str_replace($found, urldecode($link), $content);
								
							$i++;
						}
	
					}
						
						
						
	
						
					//replace thumbnails by full image for external links
					if (  stristr($content, 'safe_image.php')  ){
	
						preg_match_all('{https://[^:]*?safe_image\.php.*?url=(.*?)"}', $content, $matches);
	
						$found_imgs = $matches[0];
						$found_imgs_links = $matches[1];
	
	
						$i=0;
	
						foreach ($found_imgs as $found_img ){
								
							$found_imgs_links[$i] = preg_replace('{&.*}', '', $found_imgs_links[$i]);
	
							$found_img_link = urldecode($found_imgs_links[$i] );
							$content = str_replace($found_img, $found_img_link."\"", $content);
								
								
						}
	
							
					}
						
	
					//small images check s130x130
					if( 0 &&  stristr($content, '130x130') || 0 && $type == 'photo' ){
						echo '<br>Small images found extracting full images..';
	
						preg_match_all('{"https://[^"]*?\w130x130/(.*?)\..*?"}', $content,$matches);
	
						$small_imgs_srcs = str_replace('"', '', $matches[0]);
							
						$small_imgs_ids = $matches[1];
	
	
	
						//remove _o or _n
						$small_imgs_ids = preg_replace('{_\D}', '', $small_imgs_ids);
	
						//remove start of the id
						$small_imgs_ids = preg_replace('{^\d*?_}', '', $small_imgs_ids);
	
	
						//get oritinal page
						$x='error';
						curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
						curl_setopt($this->ch, CURLOPT_URL, trim( html_entity_decode( $url)));
						$exec=curl_exec($this->ch);
						$x=curl_error($this->ch);
							
							
						if(stristr($exec, '<img class="scaled') && 0){
							echo '<br>success loaded original page';
								
							//get imgs displayed
							preg_match_all('{<img class="scaled.*?>}s', $exec,$all_scalled_imgs_matches);
							$plain_imas_html = implode(' ', $all_scalled_imgs_matches[0]) ;
								
	
								
							//get ids without date at start \d{8}_(\d*?_\d*?)_
							preg_match_all('{\d{4,8}_(\d*?_\d*?)_}', $plain_imas_html,$all_ids_imgs_matches);
								
							$all_ids_imgs = array_unique($all_ids_imgs_matches[1]);
							$small_imgs_ids = $all_ids_imgs;
								
	
	
							$firstImage = '';
							@$firstImage = $all_ids_imgs[0];
								
	
							$i=0;
							foreach ($small_imgs_ids as $small_imgs_id){
	
	
								unset($large_imgs_matches);
	
									
								//searching full image
								preg_match('{src="(https://[^"]*?'.$small_imgs_id.'.*?)"}', $exec,$large_imgs_matches);
	
								//ajaxify images
								unset($large_imgs_matches_ajax);
								preg_match('{src=(https%3A%2F%2F[^&]*?'.$small_imgs_id.'.*?)&}', $exec,$large_imgs_matches_ajax);
	
	
								if(trim($large_imgs_matches[1]) != ''){
	
									$replace_img = $large_imgs_matches[1];
										
										
										
									//check if there is a larger ajaxify image or not
									if( isset($large_imgs_matches_ajax[1]) && trim($large_imgs_matches_ajax[1]) != ''){
										$replace_img = urldecode($large_imgs_matches_ajax[1]);
									}
										
	
										
									//if first image and image in the original content differs: case: added x photos to album
									if(  $i == 0  && (! stristr($content,$small_imgs_id) || ! stristr($content, 'w130x130'))  ){
	
										echo '<br>Removing first image first';
										$content = preg_replace('{<img.*?>}', '', $content);
	
									}
										
									//echo ' Replacing  '.$small_imgs_srcs[$i] . ' with '.$replace_img;
									if( stristr($content,$small_imgs_id) ){
											
										$content = str_replace( $small_imgs_srcs[$i], $replace_img, $content);
									}else{
										$content = str_replace('<!--reset_images-->', '<img class="wp_automatic_fb_img" src="'.$replace_img.'"/><!--reset_images-->', $content);
									}
	
	
								}
	
	
									
								$i++;
							}
								
							if($type == 'video'){
								echo '<br>Extracting vid image';
	
								preg_match('{background-image: url\((.*?)\)}', $exec, $vid_img_match);
	
								$vid_img = $vid_img_match[1] ;
	
								if(trim($vid_img) != ''){
									$content = str_replace($item->picture, $vid_img, $content);
									echo '-> success';
								}else{
									echo '-> failed';
								}
									
	
									
							}
								
						}else{
							echo '<br>Can not find image id at soure loaded page small img id:'.$small_imgs_ids[0];
								
						}
	
	
					}
						
					//fix links of facebook short /
					//$content = str_replace('href="/', 'href="https://facebook.com/', $content);
					$content = preg_replace('{href="/(\w)}', 'href="https://facebook.com/$1', $content);
	
					//change img class
					$content = str_replace('class="img"', 'class="wp_automatic_fb_img"', $content);
						
					//skip if no image
					if(in_array('OPT_FB_IMG_SKIP', $camp_opt)){
	
						if(  ! stristr($content, '<img')){
							echo 'Post have no image skipping...';
							continue;
						}
					}
						
	
					$ret['original_title'] = $title;
					$ret['original_link'] = $url;
					$ret['matched_content'] = $content;
					$ret['original_date'] = $wpdate;
					$ret['from_name'] = $item->from->name;
					$ret['from_id'] = $item->from->id;
					$ret['from_url'] = 'https://facebook.com/'.$item->from->id;
					$ret['from_thumbnail'] = 'https://graph.facebook.com/'.$item->from->id.'/picture?type=large';
					$ret['post_id'] = $item_id;
					$ret['post_id_single'] =  $id_parts[1] ;
						
					//shares
					$shares_count = $item->shares->count;
						
					if(!is_numeric($shares_count)) $shares_count = 0 ;
						
					$ret['shares_count'] = $shares_count;
						
					if(trim($title) == '') $ret['original_title']= '(notitle)';
					
					//embed code
					$ret['post_embed'] = '<div id="fb-root"></div>
<script>
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id))
        return;
    js = d.createElement(s);
    js.id = id;
    js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
    fjs.parentNode.insertBefore(js, fjs);
}(document, \'script\', \'facebook-jssdk\'));
</script>
<div class="fb-post" data-href="https://www.facebook.com/'.$ret['from_id'].'/posts/'. $id_parts[1] .'"></div>';
					
					return $ret;
	
	
						
				}//endforeach
	
				echo '<br>End of available items reached....';
	
				if(in_array('OPT_FB_CACHE', $camp_opt)){
	
					echo '<br>Deleting cache as no more valid items found...';
					delete_post_meta($camp->camp_id,'wp_automatic_cache');
						
				}
	
			}else{
				echo '<br>Unexpected api response: '.$x.$exec;
	
			}//wp error
				
		}//trim pageid
	}
	
	
}