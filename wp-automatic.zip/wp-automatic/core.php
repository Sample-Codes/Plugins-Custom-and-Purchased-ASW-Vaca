<?php
		 
		// spintax
		require_once ('inc/class.spintax.php');
		
		// amazon
		require_once ('inc/amazon_api_class.php');
		
		// youtube
		require_once ('inc/youtube_class.php');
		
		/*
		 * ---* Auto Link Builder Class ---
		 */
		class wp_automatic {
			public $ch = '';
			public $db = '';
			public $spintax = '';
			public $plugin_url = '';
			public $wp_prefix = '';
			public $used_keyword = '';
			public $used_link ='';
			public $used_tags = '' ;
			public $duplicate_id = '';
			public $cached_file_path = '';
			public $minimum_post_timestamp = '';
			public $minimum_post_timestamp_camp = '';
			public $debug = false;
			public $translationSuccess ; 
			
			/*
			 * ---* Class Constructor ---
			 */
			function wp_automatic() {
				// plugin url
				$siteurl = get_bloginfo ( 'url' );
				$this->plugin_url = $siteurl . '/wp-content/plugins/alb/';
				
				// db
				global $wpdb;
				$this->db = $wpdb;
				$this->wp_prefix = $wpdb->prefix;
				// $this->db->show_errors();
				@$this->db->query ( "set session wait_timeout=28800" );
				
				// curl
				$this->ch = curl_init ();
				curl_setopt ( $this->ch, CURLOPT_HEADER, 0 );
				curl_setopt ( $this->ch, CURLOPT_RETURNTRANSFER, 1 );
				curl_setopt ( $this->ch, CURLOPT_CONNECTTIMEOUT, 10 );
				curl_setopt ( $this->ch, CURLOPT_TIMEOUT, 200 );
				curl_setopt ( $this->ch, CURLOPT_REFERER, 'http://www.bing.com/' );
				curl_setopt ( $this->ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.8) Gecko/2009032609 Firefox/3.0.8' );
				curl_setopt ( $this->ch, CURLOPT_MAXREDIRS, 20 ); // Good leeway for redirections.
				@curl_setopt ( $this->ch, CURLOPT_FOLLOWLOCATION, 1 ); // Many login forms redirect at least once.
				
			 	curl_setopt ( $this->ch, CURLOPT_COOKIEJAR, str_replace('core.php', 'cookie.txt', __FILE__) );
			 	curl_setopt ( $this->ch, CURLOPT_COOKIEJAR,  'cookie.txt' );
			  	curl_setopt ( $this->ch, CURLOPT_SSL_VERIFYPEER, false );
				
				 /*
				//verbose	
				$verbose=fopen( str_replace('core.php', 'verbose.txt', __FILE__)  , 'w');
				curl_setopt($this->ch, CURLOPT_VERBOSE , 1);
				curl_setopt($this->ch, CURLOPT_STDERR,$verbose);
				*/
				 
				
				// spintax
				$this->spintax = new Spintax ();
			}
	 		
			/*
			 * ---* Function Process Campaigns ---
			 */
			function process_campaigns($cid = false) {
				
				// DB prefix
				$prefix = $this->db->prefix;
				
				// Single or all check
				if (trim ( $cid ) == '') {
					
					// All campaings
					$last = get_option ( 'gm_last_processed', 0 );
					
					// get all the campaigns from the db lower than the last processed
					$query = "SELECT * FROM {$this->wp_prefix}automatic_camps  where camp_id < $last ORDER BY camp_id DESC";
					$camps = $this->db->get_results ( $query );
					
					// check if results returned with id less than the last processed or not if not using regular method
					$query = "SELECT * FROM {$this->wp_prefix}automatic_camps WHERE  camp_id >= $last ORDER BY camp_id DESC";
					$camps2 = $this->db->get_results ( $query );
					
					// merging 2 arrays
					$camps = array_merge ( $camps, $camps2 );
				} else {
					
					// Single campaign process
					$query = "SELECT * FROM {$this->wp_prefix}automatic_camps  where camp_id = $cid ORDER BY camp_id DESC";
					$camps = $this->db->get_results ( $query );
				}
				 
				// check if need to process camaigns or skip
				if (count ( $camps ) == 0) {
					echo '<br>No valid campaigns to process ';
					return;
				}else{
					if(trim($cid) == '')
					echo '<br>DB contains '.count($camps).' campaigns<br>';
				}
				
				// now processing each fetched campaign
				$i = 0;
				foreach ( $camps as $campaign ) {
					
					// reading post status
					$status = get_post_status ( $campaign->camp_id );
					
					// if published process
					if ($status == 'publish') {
						if ($i != 0)
							echo '<br>';
						echo "<b>Processing Campaign</b> $campaign->camp_name {  $campaign->camp_id  }";
						 
						// updating the last id processed
						update_option ( 'gm_last_processed', $campaign->camp_id );
				 		
						//check if deserve spinning now or not
						if(trim($cid) == false){
								
							//read post every x minutes
							if( stristr($campaign->camp_general, 'a:') ) $campaign->camp_general=base64_encode($campaign->camp_general);
							$camp_general = unserialize (base64_decode( $campaign->camp_general) );
							$camp_general=array_map('stripslashes', $camp_general);
							
							if(! is_array($camp_general) || ! isset($camp_general['cg_update_every']) ){
								$camp_general = array('cg_update_every'=>60 ,'cg_update_unit'=> 1);
							}
								
							$post_every = $camp_general['cg_update_every'] * $camp_general['cg_update_unit'];
								
							echo '<br>Campaign scheduled to process every '.$post_every . ' minutes ';
							
							//get last check time 
							$last_update=get_post_meta($campaign->camp_id,'last_update',1);
							if(trim($last_update) == '') $last_update =1388692276 ;
							//echo '<br>Last updated stamp '.$last_update;
							
							$difference = $this->get_time_difference($last_update, time());
							
							echo '<br> last processing was <strong>'.$difference. '</strong> minutes ago ';
							
							if($difference > $post_every ){
								echo '<br>Campaign passed the time and eligible to be processed';
								update_post_meta($campaign->camp_id,'last_update',time());
		
								$this->log ( '<strong>Cron</strong> >> eligible waiting campaign' , $campaign->camp_name .'{'.$campaign->camp_id .'} last processing was <strong>'.$difference. '</strong> minutes ago ');
								
								//process
								$this->log ( '<strong>Cron</strong> >> Processing Campaign:' . $campaign->camp_id, $campaign->camp_name .'{'.$campaign->camp_id .'}');
								$this->process_campaign ( $campaign );
							}else{
								echo '<br>Campaign still not passed '.$post_every . ' minutes';
							}
							
							
						}else{
							
							// No cron just regular call
							
							// update last run
							update_post_meta($campaign->camp_id,'last_update',time());
							
							// process
							$this->log ( '<strong>User</strong> >> Processing Campaign:' . $campaign->camp_id, $campaign->camp_name .'{'.$campaign->camp_id .'}' );
							$this->process_campaign ( $campaign );
							
						}
						
						
						
						$i ++;
					} elseif (! $status) {
						// deleting Camp record
						$query = "delete from {$this->wp_prefix}automatic_camps where camp_id= '$campaign->camp_id'";
						$this->db->query ( $query );
						// deleting matching records for keywords
						$query = "delete from {$this->wp_prefix}automatic_keywords where keyword_camp ='$campaign->camp_id'";
						$this->db->query ( $query );
					}else{
						echo 'Campaign should be published firstly to run..';
					}
				}
			}
			
			/*
			 * ---* Processing Single Campaign Function ---
			 */
			function process_campaign($camp) {
				
				// ini
				$camp_post_every = $camp->camp_post_every;
				$wp_automatic_tw = get_option ( 'wp_automatic_tw', 400 );
				$wp_automatic_options = get_option('wp_automatic_options',array() );
				$camp_type = $camp->camp_type;
				$camp_post_custom_k = unserialize ( $camp->camp_post_custom_k );
				$camp_post_custom_v = unserialize ( $camp->camp_post_custom_v );
				
				//camp general options
				if( stristr($camp->camp_general, 'a:') ) $camp->camp_general=base64_encode($camp->camp_general);
				$camp_general = unserialize ( base64_decode( $camp->camp_general) );
				@$camp_general=array_map('stripslashes', $camp_general);
				
				// get the count of posted posts so far
				$key = 'Posted:' . $camp->camp_id;
				$query = "select count(id) as count from {$this->wp_prefix}automatic_log where action='$key'";
				$temp = $this->db->get_results ( $query );
				$temps = $temp [0];
				$posted = $temps->count;
				
				
				// if maximum reached skip
				if ($camp_post_every <= $posted) {
					echo '<br>Maximum Num Posted ';
					$this->log('Cancel Campaign', 'campaign reached maximum number of posts');
					return false;
				}
				
				// campaign options
				$camp_opt = unserialize ( $camp->camp_options );
				if (! is_array ( $camp_opt ))
					$camp_opt = array ();
					
				// reading keywords that need to be processed
				$keywords = explode ( ',', $camp->camp_keywords );
				$keywords=array_filter($keywords);
				$keywords=array_map('trim', $keywords);
				
				// set minimum item date if exists
				if(in_array('OPT_YT_DATE', $camp_opt)){
					$this->minimum_post_timestamp = strtotime($camp_general['cg_yt_dte_year'].'-'.$camp_general['cg_yt_dte_month'].'-'.$camp_general['cg_yt_dte_day'].'T00:00:00.000Z');
					$this->minimum_post_timestamp_camp = $camp->camp_id;
				}
				
				//Rotate Keywords
				if(in_array('OPT_ROTATE', $camp_opt)){
					echo '<br>Rotating Keywords Enabled';
		
					//last used keyword 
					$last_keyword = get_post_meta($camp->camp_id ,'last_keyword',1);
					
					if( ! trim($last_keyword) == ''){
						//found last keyword usage let's split
						echo '<br>Last Keyword: '.$last_keyword;
		
						//add all keywords after the last keyword
						$add = false;
						foreach ($keywords as $current_keword){
							if($add){
								//set add flag to add all coming keywords
								$rotatedKeywords[]=$current_keword;
								
							}elseif (trim($current_keword) == trim($last_keyword)) {
								$add = true; 
							} 
						}
						
					  //add all keywords before the last keyword
						foreach ($keywords as $current_keword){
							$rotatedKeywords[]=$current_keword;
							if(trim($current_keword) == trim ($last_keyword)) break ;
						
						}
						
					  //set keywords to rotated keywords
						if( count($rotatedKeywords) != 0 ) $keywords = $rotatedKeywords;
						$keywordsString = implode(',', $rotatedKeywords);
						$camp->camp_keywords=$keywordsString;
					 } 
				 }
				 
				 //Rotate feeds
				 if(in_array('OPT_ROTATE_FEEDS', $camp_opt)){
				 	echo '<br>Rotating feeds Enabled';
				 		
				 	//last used feed
				 	$last_feed = get_post_meta($camp->camp_id ,'last_feed',1);
				 	 
				 	if( ! trim($last_feed) == ''){
				 		//found last feed usage let's split
				 		echo '<br>Last feed: '.$last_feed;
				 			
				 		//add all feeds after the last feed
				 		$add = false;
				 		$feeds = explode("\n", $camp->feeds);
				 		$feeds = array_filter($feeds);
				 		
				 		foreach ($feeds as $current_feed){
				 			
				 			if($add){
				 				//set add flag to add all coming feeds
				 				$rotatedfeeds[]=$current_feed;
				 					
				 			}elseif (trim($current_feed) == trim($last_feed)) {
				 				$add = true;
				 			}
				 		}
				 		 
				 			
				 		//add all feeds before the last feed
				 		foreach ($feeds as $current_feed){
				 			$rotatedfeeds[]=$current_feed;
				 			if(trim($current_feed) == trim ($last_feed)) break ;
				 				
				 		}
		
				 	 
				 		
				 		//set feeds to rotated feeds
				 		if( count($rotatedfeeds) != 0 ) $feeds = $rotatedfeeds;
				 		$feedsString = implode("\n", $rotatedfeeds);
				 		$camp->feeds=$feedsString;
				 	}
				 }
				
				
				$post_content = $camp->camp_post_content;
				$post_title = $camp->camp_post_title;
				
				// ini content
				$abcont = '';
				if ($camp_type == 'Articles') {
					
					// proxyfy
					$this->fire_proxy ();
					
					$article = $this->articlebase_get_post ( $camp );
					$abcont = $article ['cont'];
					$title = $article ['title'];
					$source_link = $article ['source_link'];
					$img = $article;
					
				}elseif ($camp_type == 'ArticlesBase') {
					
					// proxyfy
					$this->fire_proxy ();
					
					$article = $this->articlebase_get_post ( $camp );
					$abcont = $article ['cont'];
					$title = $article ['title'];
					$source_link = $article ['source_link'];
					$img = $article;	
					
				} elseif ($camp_type == 'Feeds') {
					// feeds posting
					echo '<br>Should get content from feeds';
					$article = $this->feeds_get_post ( $camp );
					$abcont = $article ['cont'];
					$title = $article ['title'];
					$source_link = $article ['source_link'];
					$img = $article;
				} elseif ($camp_type == 'Amazon') {
					echo '<br>Amazon product is required';
					$product = $this->amazon_get_post ( $camp );
					
					//update offer url to add to chart
		 
					if ( in_array('OPT_LINK_CHART', $camp_opt) ) {
					 
						$product['product_link'] = $product['chart_url'];
						 
					}  
				 
					$img =$product;
				 
					$abcont = @$product ['offer_desc'];
					$title = @$product ['offer_title'];
					$source_link = @$product ['offer_url'];
					$product_img = @$product ['offer_img'];
					$product_price = @$product ['offer_price'];
				} elseif ($camp_type == 'Clickbank') {
					
					echo '<br>Clickbank product is required';
					$img = $product = $this->clickbank_get_post ( $camp );
					$abcont = $product ['offer_desc'];
					$title = $product ['title'];
					$source_link = $product ['offer_link'];
					$product_img = $product ['img'];
					$product_original_link = $product ['original_link'];
					
					// print_r($product);
				} elseif ($camp_type == 'Youtube') {
					echo '<br>Youtube Vid is required';
					$img = $vid = $this->youtube_get_post ( $camp );
					$abcont = $vid ['vid_desc'];
					$original_title = $vid ['vid_title'];
					$title = $vid ['vid_title'];
					$source_link = $vid ['vid_url'];
				
				} elseif($camp_type == 'Vimeo'){
				
					echo '<br>Vimeo campaign let\'s get vimeo vid';
					
					$img = $vid = $this->vimeo_get_post ( $camp );
		
					//set player width and hieght 
					
					$abcont = $vid ['vid_description'];
					$original_title = $vid ['vid_title'];
					$title = $vid ['vid_title'];
					$source_link = $vid ['vid_url'];
					
				} elseif ($camp_type == 'Flicker') {
					echo '<br>Flicker image is required';
					$img = $this->flicker_get_post ( $camp );
					
					$abcont = $img ['img_description'];
					$original_title = $img ['img_title'];
					$title = $img ['img_title'];
					$source_link = $img ['img_link'];
				} elseif ($camp_type == 'eBay') {
					echo '<br>eBay item is required';
					$img = $this->ebay_get_post ( $camp );
					
					$abcont = $img ['item_desc'];
					$original_title = $img ['item_title'];
					$title = $img ['item_title'];
					$source_link = $img ['item_link'];
				}elseif($camp_type == 'Spintax'){
					
					echo '<p>Processing spintax campaign';
					
					$abconts =$post_title . '(99999)' . $post_content;
					 
					if( in_array('OPT_TBS', $camp_opt) ){
						$abconts  = $this->spin ( $abconts );
					}
					
					
					$abconts = $this->spintax->spin ( $abconts );
					$tempz = explode ( '(99999)', $abconts );
					
					// Rewrite the title
					if(! in_array('OPT_TBS_TTL', $camp_opt)){
						echo '<br>Spinning the title';
						$post_title = $tempz [0];
					}
					
					
					$post_content = $tempz [1];
					$title =trim($post_title);
					$img=array();
				}elseif( $camp_type == 'Facebook' ){
					
					 $img = $this->fb_get_post($camp);
					
					 $abcont = '';
					 $original_title = $img ['original_title'];
					 $title = $img ['original_title'];
					 $source_link = $img ['original_link'];
					  
				}elseif ($camp_type == 'Pinterest' ){
					
					 $img = $this->pinterest_get_post($camp);
		 
					 $abcont = $img ['pin_description'];
					 $original_title = $img ['pin_title'];
					 $title = $img ['pin_title'];
					 $source_link = $img ['pin_url'];
					  
				}elseif ($camp_type == 'Instagram' ){
					
					 $img = $this->instagram_get_post($camp);
		 
					 $abcont = $img ['item_description'];
					 $original_title = $img ['item_title'];
					 $title = $img ['item_title'];
					 $source_link = $img ['item_url'];
					  
				}elseif($camp_type == 'Twitter' ){
					
					$img = $this->twitter_get_post($camp);
					 	
					$abcont = $img ['item_description'];
					$original_title = $img ['item_title'];
					$title = $img ['item_title'];
					$source_link = $img ['item_url'];
					
					
				}elseif($camp_type == 'SoundCloud' ){
					
					$img = $this->sound_get_post($camp);
					 	
					$abcont = $img ['item_description'];
					$original_title = $img ['item_title'];
					$title = $img ['item_title'];
					$source_link = $img ['item_url'];
					
					
				}elseif($camp_type == 'Craigslist' ){
					
					$img = $this->craigslist_get_post($camp);
					 	
					$abcont = $img ['item_description'];
					$original_title = $img ['item_title'];
					$title = $img ['item_title'];
					$source_link = $img ['item_link'];
					
					
				}
			 
				
				
				//limit the content returned
				if(in_array('OPT_LIMIT', $camp_opt)){
					echo '<br>Triming post content to '.$camp_general['cg_content_limit'] . ' chars';
					$abcont = $this->truncateHtml($abcont,$camp_general['cg_content_limit']);
				}
				
				if(in_array('OPT_LIMIT_TITLE', $camp_opt) && trim($title) != ''){
					echo '<br>Triming post title to '.$camp_general['cg_title_limit'] . ' chars';
					
					$titleCharsCount = $this->chars_count($title);
					
					if( $camp_general['cg_title_limit'] < $titleCharsCount ){
					
						if(function_exists('mb_substr')){
							$title = mb_substr($title, 0,$camp_general['cg_title_limit']);
						}else{
							$title = substr($title, 0,$camp_general['cg_title_limit']);
							
						}
						
						$title = $this->removeEmoji($title);
						$title = $title . '...';
						
					}
		
				}
				 
				
				// check if valid content fetched
				if (trim ( $title ) != '') {
					
					// validate if the content contains wanted or execluded texts
					
					$valid = true;
					
					$exact = $camp->camp_post_exact;
					$execl = $camp->camp_post_execlude;
					
					
					// validating exact
					if (trim ( $exact ) != '' & in_array('OPT_EXACT', $camp_opt) && ! in_array('OPT_EXACT_AFTER', $camp_opt)) {
						$valid = false;
						$exactArr = explode ( "\n", trim ( $exact ) );
						
						foreach ( $exactArr as $wordexact ) {
							if (trim ( $wordexact != '' )) {
								if (  preg_match ( '/\b' . trim ( $wordexact ) . '\b/iu', html_entity_decode($abcont) ) ||  preg_match ( '/\b' . trim ( $wordexact ) . '\b/iu', html_entity_decode($title) )   ) {
									
									echo '<br>Content contains the word : ' . $wordexact ;
									$valid = true;
									break;
								}else{
									echo '<br>Content don\'t contain the word : ' . $wordexact . ' try another ';
								} // match
							} // trim wordexact
						} // foreach exactword
					} // trim exact
		 			
					// validating execlude
					if ($valid == true) {
						if (trim ( $execl ) != '' && in_array('OPT_EXECLUDE', $camp_opt) && ! in_array('OPT_EXECLUDE_AFTER', $camp_opt) ) {
							$execlArr = explode ( "\n", trim ( $execl ) );
							
							foreach ( $execlArr as $wordex ) {
								 
								if (trim ( $wordex != '' )) {
									if ( preg_match ( '/\b' . trim (  $wordex  ) . '\b/iu', html_entity_decode($abcont) ) || preg_match ( '/\b' . trim (  $wordex  ) . '\b/iu', (html_entity_decode($title)) )   ) {
										echo '<br>Content contains the banned word :' . $wordex . ' getting another ';
										$valid = false;
										break;
									}  
								} // trim wordexec
							} // foreach wordex
						} // trim execl
					} // valid
					  
					// if not valid process the campaign again and exit
					if ($valid == false) {
						
						//blacklisting the link so we don'g teg it again and cause a loop
						update_post_meta($camp->camp_id,'_execluded_links', get_post_meta($camp->camp_id,'_execluded_links',1).','.$source_link );
		 				$this->process_campaign ( $camp );
						exit ();
					}
					
					// strip links
					if (in_array ( 'OPT_STRIP', $camp_opt )) {
						echo '<br>Striping links ';
						//$abcont = strip_tags ( $abcont, '<p><img><b><strong><br><iframe><embed><table><del><i><div>' );
						$abcont = preg_replace('{<a.*?>(.*?)</a>}', '$1', $abcont);
						
						/*
						if(in_array('OPT_STRIP_INLINE', $camp_opt)){
							echo '...striping inline links';
							$abcont = preg_replace('/https?:\/\/[^<\s]+/', '', $abcont);
						}*/
						 
						
					}
					
					
			 
					
					// translate the cotent
					if (in_array ( 'OPT_TRANSLATE', $camp_opt ) && trim ( $abcont ) != '') {
						echo '<br>Translating the post...' . $title;
						
						 	
							// Translation Method 
							$translationMethod = $camp_general['cg_translate_method'];
							
							if($translationMethod != 'googleTranslator'){
								$translationMethod = 'microsoftTranslator';
							}
						
							// Translation success flag
							$this->translationSuccess = false ;
							
							$translation = $this->gtranslate ( $title, $abcont, $camp->camp_translate_from, $camp->camp_translate_to ,$translationMethod);
							 
							if (in_array ( 'OPT_TRANSLATE_TITLE', $camp_opt )) {
								$title = $translation [0];
							}
							
							$abcont = $translation [1];
							
							// check if another translation needed
							if (trim ( $camp->camp_translate_to_2 ) != 'no' && trim($camp->camp_translate_to_2) !='' ) {
								// another translate
								 
								echo '<br>translating the post another time ';
								$translation = $this->gtranslate ( $title, $abcont, $camp->camp_translate_to, $camp->camp_translate_to_2 ,$translationMethod);
								
								if (in_array ( 'OPT_TRANSLATE_TITLE', $camp_opt )) {
									$title = $translation [0];
								}
								
								$abcont = $translation [1];
							}
						
							
							 
					}
					
					// replacing general terms title and source link
					$post_content = @str_replace ( '[source_link]', $source_link, $post_content );
					$post_title = @str_replace ( '[original_title]', $title, $post_title );
					$post_content = str_replace ( '[original_title]', $title, $post_content );
					
					if ($camp_type == 'Feeds' || $camp_type == 'Articles' || $camp_type == 'ArticlesBase') {
						
						 
							$post_content = str_replace ( '[matched_content]', $abcont, $post_content );
						 
						
					} elseif ($camp_type == 'Amazon') {
						
						$post_content = str_replace ( '[product_desc]', $abcont, $post_content );
						$post_content = str_replace ( '[product_img]', $product_img, $post_content );
						//$post_content = str_replace ( '[product_link]', $source_link, $post_content );
						$post_content = str_replace ( '[product_price]', $product_price, $post_content );
					} elseif ($camp_type == 'Clickbank') {
						$post_content = str_replace ( '[product_desc]', $abcont, $post_content );
						$post_content = str_replace ( '[product_img]', $product_img, $post_content );
						$post_content = str_replace ( '[product_link]', $source_link, $post_content );
						$post_content = str_replace ( '[product_original_link]', $product_original_link, $post_content );
					} elseif ($camp_type == 'Youtube') {
						
						$post_content = str_replace ( '[vid_player]', addslashes ( $vid ['vid_player'] ), $post_content );
						$post_content = str_replace ( '[vid_desc]', $abcont, $post_content );
						$post_content = str_replace ( '[vid_views]', $vid ['vid_views'], $post_content );
						$post_content = str_replace ( '[vid_rating]', $vid ['vid_rating'], $post_content );
						$post_content = str_replace ( '[vid_img]', $vid ['vid_img'], $post_content );
					}elseif($camp_type == 'eBay'){
						
						if(stristr($post_content, '[item_images]') && is_array($img['item_images']) ){
							
							$cg_eb_full_img_t = html_entity_decode( $camp_general['cg_eb_full_img_t']);
		
							$imgs = $img['item_images'];
							
							if(! stristr($cg_eb_full_img_t, '[img_src]') ) {
								$cg_eb_full_img_t = '<img src="[img_src]" class="wp_automatic_gallery" />';
							} 
							
							$contimgs='';
							foreach ($imgs as $newimg){
								$tempimg =$cg_eb_full_img_t;
								$contimgs.= str_replace('[img_src]', $newimg, $tempimg);
							}
							
							$post_content = str_replace('[item_images]', $contimgs, $post_content);
							
						}
						
						
						
						
					}elseif ($camp_type == 'Flicker'   ) {
					
						$post_content = str_replace ( '[img_description]', $abcont, $post_content );
					
					} elseif( $camp_type == 'Vimeo' ) {	
						
						//set player width and height 
						$vm_width = $camp_general['cg_vm_width'];
						$vm_height = $camp_general['cg_vm_height'];
						
						if(trim($vm_width)!= ''){
							$img['vid_embed'] = $vid['vid_embed'] = str_replace('width="560"', 'width="'.$vm_width.'"', $vid['vid_embed']);
						}
		
						if(trim($vm_height)!= ''){
							$img['vid_embed'] = $vid['vid_embed'] = str_replace('height="315"', 'height="'.$vm_height.'"', $vid['vid_embed']);
						}
		
					}elseif( $camp_type == 'Pinterest' ){ 	
						
						$post_content = str_replace ( '[pin_description]', $abcont, $post_content );
		
					}elseif( $camp_type == 'Instagram' ){
						
					}elseif( $camp_type == 'Twitter' ){
						
					}elseif( $camp_type == 'SoundCloud' || $camp_type == 'Craigslist' ){
						
						
					} else {
						$post_content .= "<br>$abcont";
					}
					
					// Replacing generic tags
					if(stristr($this->used_keyword, '_')) {
						$pan=explode('_', $this->used_keyword);
						$this->used_keyword = $pan[1];
					}
					
					$post_content = str_replace('[keyword]', $this->used_keyword, $post_content);
					$post_title = str_replace('[keyword]', $this->used_keyword, $post_title);
				 
					foreach ( $img as $key => $val ) {
						
						if( ! is_array($val)){
							$post_content = str_replace ( '[' . $key . ']', $val, $post_content );
							$post_title = str_replace ( '[' . $key . ']', $val, $post_title );
						}
					
					}
					 
					
					// replacing the keywords with affiliate links
					if (in_array ( 'OPT_REPLACE', $camp_opt )) {
						foreach ( $keywords as $keyword ) {
							
							$keyword = trim($keyword);
							
							if (trim ( $keyword != '' )) {
								//$post_content = str_replace ( $keyword, '<a href="' . $camp->camp_replace_link . '">' . $keyword . '</a>', $post_content );
								
								$post_content = preg_replace ( '/\b'.preg_quote($keyword,'/').'\b/', '<a href="' . $camp->camp_replace_link . '">' . $keyword . '</a>', $post_content );
							}
						}
					}
					
				
					
					//replacing patterns 
					if(in_array('OPT_RGX_REPLACE', $camp_opt)){
						
						$regex_patterns = trim($camp_general['cg_regex_replace']);
						echo '<br>Replacing using REGEX';
						
						//protecting tags 
						if(in_array('OPT_RGX_REPLACE_PROTECT', $camp_opt)){
							echo '..protecting tags.';
							
							preg_match_all("/<[^<>]+>/is",$post_content,$matches,PREG_PATTERN_ORDER);
							$htmlfounds=$matches[0];
							
							 	
							//extract all fucken shortcodes
							$pattern="\[.*?\]";
							preg_match_all("/".$pattern."/s",$post_content,$matches2,PREG_PATTERN_ORDER);
							$shortcodes=$matches2[0];
							
							$htmlfounds = array_merge($htmlfounds,$shortcodes);
							
							$htmlfounds = array_filter( array_unique($htmlfounds) );
							
							 
							$i=1;
							foreach ($htmlfounds as $htmlfound){
								 
								 
								
								$post_content = str_replace($htmlfound, "[" . str_repeat('*', $i) . "]", $post_content);
								$i++;
								
							}
							
							 
						}
						
						if(stristr($regex_patterns, '|')){
							$regex_patterns_arr = explode("\n",$regex_patterns);
							
							foreach ($regex_patterns_arr as $regex_pattern){
								
								$regex_pattern = trim($regex_pattern);
								
								if(stristr($regex_pattern, '|')){
									
									$regex_pattern_parts = explode('|', $regex_pattern);
									
									$regex_pattern_search = $regex_pattern_parts[0];
									$regex_pattern_replace = $regex_pattern_parts[1];
									
									echo '<br>Replacing '.htmlentities($regex_pattern_search) .' with '.htmlentities($regex_pattern_replace);
									
									$post_content = preg_replace('{'.$regex_pattern_search.'}su', $regex_pattern_replace, $post_content);
									
									if(in_array('OPT_RGX_REPLACE_TTL', $camp_opt)){
										$post_title = preg_replace('{'.$regex_pattern_search.'}su', $regex_pattern_replace, $post_title);
									}
									
									
									
								}
								
								
							}
							
						}
						
						//restore protected tags
						if( isset($htmlfounds) and count($htmlfounds) >0 ){
							
							//restoring
							$i = 1;
							foreach ($htmlfounds as $htmlfound){
								$post_content = str_replace('['.str_repeat('*', $i).']', $htmlfound, $post_content);
								$i++; 
							}
							
							
						}
						
					}
					
					
					// cache images locally ?
					if (in_array ( 'OPT_CACHE', $camp_opt )) {
						
						preg_match_all ( '/<img [^>]*src=["|\']([^"|\']+)/i', stripslashes ( $post_content ), $matches );
						
						$srcs = $matches [1];
						$srcs = array_unique ( $srcs );
						$current_host = parse_url ( home_url (), PHP_URL_HOST );
						foreach ( $srcs as $image_url ) {
							
							//check inline images
							if(stristr($image_url, 'data:image')){
								 
								continue;
							}
							 
							//instantiate so we replace . note we modify image_url 
							$image_url_original = $image_url;
							
							//decode html entitiies
							$image_url = html_entity_decode($image_url);
							
							
							if(stristr($image_url, '%') ) {
								$image_url = urldecode($image_url);
								 
							}
							
							//file name to store
							$filename = basename ( $image_url );
								
							 
							//clean names
							if(in_array('OPT_CACHE_CLEAN' , $camp_opt   )){
								
								$clean_name = '';
								$clean_name =  sanitize_file_name($post_title);
								
								if(trim($clean_name) != ""){
									
									//get the image extension \.\w{3}
									
									preg_match('{\.\w{3}}', $filename,$ext_matches);
									$ext = $ext_matches[0];
									  
									
									$filename = trim($clean_name);
									
									if(stristr($ext, '.')){
										$filename = $filename . $ext;
									}
									
								}
								
							}
							
							
							
							if(stristr($image_url, '%')){
								$filename = urldecode($filename);
								 
							}
							
							
							 
							if(stristr($image_url ,' ')){
								$image_url = str_replace(' ', '%20', $image_url);
							} 
							
							$imghost = parse_url ( $image_url, PHP_URL_HOST );
							
							if(stristr($imghost, 'http://')){
								$imgrefer=$imghost;
							}else{
								$imgrefer = 'http://'.$imghost;
							}
							 
							
							if ($imghost != $current_host ) {
								echo '<br>Caching image: ' . $image_url;
								
								 
								// let's cache this image
								// set thumbnail
								$upload_dir = wp_upload_dir ();
		 						
								
								//curl get
								$x='error';
								curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
								curl_setopt($this->ch, CURLOPT_URL, trim($image_url));
								
								//empty referal 
								if(! in_array('OPT_CACHE_REFER_NULL', $camp_opt) ){
									curl_setopt ( $this->ch, CURLOPT_REFERER, $imgrefer );
								}else{
									curl_setopt ( $this->ch, CURLOPT_REFERER, '' );
								}
								
								 
								curl_setopt ( $this->ch, CURLOPT_HEADER, 0 );
								$image_data=curl_exec($this->ch);
								$image_data_md5 = md5($image_data);
								
								//check if already cached before
								$is_cached = $this->is_cached($image_url , $image_data_md5);
								if( $is_cached != false ){
									echo '<--already cached';
									$post_content = str_replace ( $image_url_original, $is_cached , $post_content );
									continue;
								}
								
								  
								$x=curl_error($this->ch);
						 
		
								if(trim($image_data) != ''){
									
									
									$x=curl_error($this->ch);
								 
									
									
									if (stristr ( $filename, '?' )) {
										$farr = explode ( '?', $filename );
										$filename = $farr [0];
									}
									
									if (wp_mkdir_p ( $upload_dir ['path'] ))
										$file = $upload_dir ['path'] . '/' . $filename;
									else
										$file = $upload_dir ['basedir'] . '/' . $filename;
										
										// check if same image name already exists
									
									if (file_exists ( $file )) {
										$filename =  time ( 'now' ) .'_'. rand(0,999)  . '_' . $filename;
										
										if (wp_mkdir_p ( $upload_dir ['path'] ))
											$file = $upload_dir ['path'] . '/' . $filename;
										else
											$file = $upload_dir ['basedir'] . '/' . $filename;
									} else {
									}
									
									 
									file_put_contents ( $file, $image_data );
									$file_link = $upload_dir ['url'] . '/' . $filename;
									
									// replace original src with new file link
									$post_content = str_replace ( $image_url_original, $file_link, $post_content );
									$this->img_cached($image_url_original, $file_link,$image_data_md5,$file);
									
									echo '<-- cached';
								}else{
									echo '<-- can not get image content '.$x;
								}
								
							
							}
						} // end foreach image
					}
					
					// replacing words that should be replaced
					$sets = stripslashes(get_option ( 'wp_automatic_replace', '' ) );
					
					
					//exit;
					$sets_arr = explode ( "\n", $sets );
					
					foreach ( $sets_arr as $set ) {
						if (trim ( $set ) != '' && stristr ( $set, '|' )) {
							
							// valid set let's replace
							$set_words = explode ( '|', $set );
							 
							
							// cleaning empty words
							$i = 0;
							foreach ( $set_words as $setword ) {
								if (trim ( $setword ) == '') {
									unset ( $set_words [$i] );
								}
								$i ++;
							}
							
							if (count ( $set_words ) > 1) {
								// word 1
								
								$word1 = trim($set_words [0]);
								
								// randomize replacing word
								$rand = rand ( 1, count ( $set_words ) - 1 );
								$replaceword = trim($set_words [$rand]);
								
								echo '<br>replacing "'.$word1.'" by "'.$replaceword.'"' ;
								
								if( in_array('OPT_REPLACE_NO_REGEX', $wp_automatic_options) ){
									
									$post_title = str_replace  (  $word1 , $replaceword, $post_title );
									$post_content = str_replace (   $word1 , $replaceword, $post_content );
									
								}else{
									
									$post_title = preg_replace ( '/\b' . trim ( preg_quote( $word1,'/') ) . '\b/iu', $replaceword, $post_title );
									$post_content = preg_replace ( '/\b' . trim (  preg_quote( $word1,'/') ) . '\b/iu', $replaceword, $post_content );
								}
								
								
							}
						}
					}
					
				 
					$abcontTxt = $camp->camp_post_content;
					$abtitleTxt = $camp->camp_post_title;
						
					// spin the content
					if (in_array ( 'OPT_TBS', $camp_opt ) && trim ( $abcontTxt ) != ''   || stristr($abcontTxt, '{') && stristr($abcontTxt, '}')  && stristr($abcontTxt, '|')  || stristr($abtitleTxt, '{') && stristr($abtitleTxt, '}')  && stristr($abtitleTxt, '|') )  {
						
						if($camp_type != 'Spintax'){
						
							echo '<br>Spin the content enabled';
						
							 
						  
							$abconts = $post_title . '(99999)' . $post_content;
							
							if (in_array ( 'OPT_TBS', $camp_opt )){
								$abconts =$this->spin ( $abconts );
							}
							
							$abconts = $this->spintax->spin ( $abconts );
							$tempz = explode ( '(99999)', $abconts );
							
							// Rewrite the title
							if(! in_array('OPT_TBS_TTL', $camp_opt)){
								echo '<br>Spinning the title';
								$post_title = $tempz [0];
							}
							
							$post_content = $tempz [1];
							
							
							  
							
						}//not spintax
					}
					
					//remove nospin tags
					$post_title = str_replace('[nospin]', '', $post_title);
					$post_title = str_replace('[/nospin]', '', $post_title);
					
					$post_content = str_replace('[nospin]', '', $post_content);
					$post_content = str_replace('[/nospin]', '', $post_content);
					
					
					
					//categories for post
					if( stristr($camp->camp_post_category, ',') ) {
						$categories = array_filter(explode(',',$camp->camp_post_category ));
					}else{
						$categories = array ($camp->camp_post_category);
					}
					
					
					//check if dummy title (notitle)
					if($post_title == '(notitle)') $post_title = '';
					
					 
					// building post
					$my_post = array (
							'post_title' => strip_tags( $post_title),
							'post_content' =>  $post_content,
							'post_status' => $camp->camp_post_status,
							'post_author' => $camp->camp_post_author,
							'post_type' => $camp->camp_post_type,
							'post_category' => $categories,
							
					);
						
					
					//Pending for non english
					
					if(in_array('OPT_MUST_ENGLISH', $camp_opt)){
						echo '<br>Checking If English or not';
							
						if($this->is_english($post_title)){
							echo '<-- English ';
						}else{
							echo '<--Guessed as Not English setting as pending';
							$my_post['post_status'] = 'pending';
								 
						}
							
					}
					
					//Pending for transation fail
					// skip if translation failed
					
					if( in_array('OPT_TRANSLATE', $camp_opt) && in_array('OPT_TRANSLATE_FTP', $camp_opt)){
					
						echo '<br>Checking if translation faild..';
					
						if($this->translationSuccess == false){
							echo ' Found Failed... set to pending..';
							$my_post['post_status'] = 'pending';
						}else{
							echo ' Found succeeded ';
						}
					
					}
					
					
					//prepare author 
					if($camp_type == 'Feeds' && isset($img['author']) && trim($img['author']) != ''){
						echo '<br>Trying to set the post author to '.$img['author'];
						$author_id = $this->get_user_id_by_display_name($img['author']);
						if($author_id != false){
							$my_post['post_author'] = $author_id;	
						}
					}
					
						
					kses_remove_filters ();
					
					if ( $camp_type == 'Feeds' && in_array ( 'OPT_ORIGINAL_TIME', $camp_opt ) ){
						
						$wpdate = get_date_from_gmt( $article['wpdate'] );
						echo '<br>Setting date for the post to '.$wpdate;
						$my_post['post_date'] = $wpdate ;
					
					}
					
					if ( $camp_type == 'Craigslist' && in_array ( 'OPT_CL_TIME', $camp_opt ) ){
					
						$wpdate = get_date_from_gmt(  gmdate ( 'Y-m-d H:i:s' , strtotime($img['item_date']) )  );
						echo '<br>Setting date for the post to '.$wpdate ;
						$my_post['post_date'] = $wpdate ;
							
					}
					
					if ( $camp_type == 'Instagram' && in_array ( 'OPT_IT_DATE', $camp_opt ) ){
						echo '<br>Setting date for the post to '. $img['item_created_date'];
						$my_post['post_date']=$img['item_created_date'];
					}
					
					if (  ($camp_type == 'Twitter' && in_array ( 'OPT_IT_DATE', $camp_opt )) || ($camp_type == 'SoundCloud' && in_array('OPT_SC_DATE', $camp_opt))    ){
						
						$item_created_at = date ( 'Y-m-d H:i:s' , strtotime( $img['item_created_at'])  );
						$item_created_at = get_date_from_gmt($item_created_at);
						
						echo '<br>Setting date for the post to '.$item_created_at;
						$my_post['post_date']=$item_created_at;
						
					}
					
 					
					if ( $camp_type == 'Youtube' && in_array ( 'OPT_YT_ORIGINAL_TIME', $camp_opt ) ){
						
						$realDate = date('Y-m-d H:i:s' ,$vid['vid_time'] );
						
						echo '<br>Setting date for the post to '. $realDate;
						$my_post['post_date']= $realDate ;  
						
					}
					
					if ( $camp_type == 'Vimeo' && in_array ( 'OPT_VM_ORIGINAL_TIME', $camp_opt ) ){
						$realDate =   $vid['vid_created_time']  ;
					 	echo '<br>Setting date for the post to '. $realDate;
						$my_post['post_date']= $realDate ;
							
					}
					
					if ( $camp_type == 'Facebook' && in_array ( 'OPT_ORIGINAL_FB_TIME', $camp_opt ) ){
						$realDate = $img['original_date']; 
						echo '<br>Setting date for the post to '. $realDate;
						$my_post['post_date']= $realDate ;
							
					}
					
					//set excerpt of amazon product post type 
					if($camp_type == 'Amazon' && $camp->camp_post_type == 'product' && in_array('OPT_AMAZON_EXCERPT', $camp_opt)){
						echo '<br>Setting product short description';
						$my_post['post_excerpt'] = $img['product_desc'];
					}
					
					//remove filter kses for security 
					remove_filter('content_save_pre', 'wp_filter_post_kses');
					
					 
					//fixing utf8
					
					//echo ' Fixing ... '.$my_post['post_content'];
					
					$my_post['post_content'] = $this->fix_utf8($my_post['post_content']);
					$my_post['post_title'] = $this->fix_utf8($my_post['post_title']);
					 
					//SNAP fix 
					if(  defined('NextScripts_SNAP_Version') &&  ! function_exists('restore_current_blog')){
						echo '<br>SNAP detected applying a workaround';
						require_once ABSPATH.'/'. WPINC .'/ms-blogs.php';
					}
					
					// Exact match check 
					// validating exact
					$valid = true;
					if (trim ( $exact ) != '' & in_array('OPT_EXACT', $camp_opt) &&   in_array('OPT_EXACT_AFTER', $camp_opt)) {
						$valid = false;
						$exactArr = explode ( "\n", trim ( $exact ) );
					
						foreach ( $exactArr as $wordexact ) {
							if (trim ( $wordexact != '' )) {
								if (  preg_match ( '/\b' . trim ( $wordexact ) . '\b/iu', html_entity_decode($post_content) ) ||  preg_match ( '/\b' . trim ( $my_post['post_content'] ) . '\b/iu', html_entity_decode($title) )   ) {
										
									echo '<br>Content contains the word : ' . $wordexact ;
									$valid = true;
									break;
								}else{
									echo '<br>Content don\'t contain the word : ' . $wordexact . ' try another ';
								} // match
							} // trim wordexact
						} // foreach exactword
					} // trim exact
					
					// validating execlude
					if ($valid == true) {
						if (trim ( $execl ) != '' && in_array('OPT_EXECLUDE', $camp_opt) &&  in_array('OPT_EXECLUDE_AFTER', $camp_opt) ) {
							$execlArr = explode ( "\n", trim ( $execl ) );
								
							foreach ( $execlArr as $wordex ) {
									
								if (trim ( $wordex != '' )) {
									if ( preg_match ( '/\b' . trim (  $wordex  ) . '\b/iu', html_entity_decode($my_post['post_content']) ) || preg_match ( '/\b' . trim (  $wordex  ) . '\b/iu', (html_entity_decode($title)) )   ) {
										echo '<br>Content contains the banned word :' . $wordex . ' getting another ';
										$valid = false;
										break;
									}
								} // trim wordexec
							} // foreach wordex
						} // trim execl
					} // valid
					
					// if not valid process the campaign again and exit
					if ($valid == false) {
					
						//blacklisting the link so we don'g teg it again and cause a loop
						update_post_meta($camp->camp_id,'_execluded_links', get_post_meta($camp->camp_id,'_execluded_links',1).','.$source_link );
						$this->process_campaign ( $camp );
						exit ();
					}
					
					// Insert the post into the database
					$id = wp_insert_post ( $my_post );
					
					if($id == 0){
						echo '<br>Error:Post Insertion failure';
						//print_r($my_post);
					}
					
					 
					//wpml integration
					if(in_array('OPT_WPML', $camp_opt)  && function_exists('icl_object_id') ){
						include_once( WP_PLUGIN_DIR . '/sitepress-multilingual-cms/inc/wpml-api.php' );
						$language_code = $camp_general['cg_wpml_lang']; // change the language code
						echo '<br>Setting WPML language to: '.$language_code;
						wpml_update_translatable_content('post_'.$camp->camp_post_type, $id, trim($language_code) );
					}
					 
					//returning the security filter
					add_filter('content_save_pre', 'wp_filter_post_kses');
					
					//setting categories for custom post types
					if(  $camp->camp_post_type != 'post'){
						
						$customPostTaxonomies = get_object_taxonomies($camp->camp_post_type);
							
						if(count($customPostTaxonomies) > 0)
						{
							 
							foreach($customPostTaxonomies as $tax)
							{
								 
								if(is_taxonomy_hierarchical($tax)){
									echo '<br>Setting taxonomy '.$tax.' to '.$camp->camp_post_category;
									@wp_set_post_terms($id, $categories , $tax,true);
								}
							}
						}
						
						
						
					}else{
						 
					} 
					 
					//feeds category 
					if($camp_type == 'Feeds' && trim($img['cats'] != '')){
						
						add_post_meta ( $id, 'original_cats', $img['cats'] );
						
						if(in_array('OPT_ORIGINAL_CATS', $camp_opt)){
						
							echo '<br>Setting Categories to :'.$img['cats'];
							
							$cats= array_filter(explode(',', $img['cats']));
							
							if( $camp->camp_post_type == 'post' ){
								$taxonomy = 'category';
							}else{
								$taxonomy =  $camp_general['cg_camp_tax'] ;
							}
							
							$new_cats = array();
							
							//convert cats to ids
							foreach($cats as $cat_name){
								
								$cat  = get_term_by('name', $cat_name , $taxonomy);
								
								//check existence
								if($cat == false){
								
									
									//cateogry not exist create it
									$cat = wp_insert_term($cat_name, $taxonomy);
								
									if( ! is_wp_error($cat) ){
										//category id of inserted cat
										$cat_id = $cat['term_id'] ;
										$new_cats[] = $cat_id;
									}
									
								
								}else{
								
									//category already exists let's get it's id
									$cat_id = $cat->term_id ;
									$new_cats[] = $cat_id;
								}
								
								
								
							}
							
							//insert cats
							if(count($new_cats) > 0) 
							wp_set_post_terms($id,$new_cats,$taxonomy ,true);
							
						}
						
					}
					
					// Feeds part to field extraction set
					if($camp_type == 'Feeds'){
						
						$customFieldsArr = $img['custom_fields'];
						
						if( is_array($customFieldsArr) && count($customFieldsArr) != 0 ){
							
							foreach ($customFieldsArr as $customFieldSet){
								add_post_meta ( $id, $customFieldSet[0], $customFieldSet[1] );
							}//foreach field
						
						}//if array
					
					}//if feed
					
					$post_id = $id;
					add_post_meta ( $id, 'original_title', $title );
					@add_post_meta ( $id, 'original_link', $source_link );
					
					// Record link if posted before
					if (in_array('OPT_LINK_ONCE', $camp_opt)){
						
						$query="insert into {$this->wp_prefix}automatic_links(	link_url ,link_keyword ) values ('".md5($source_link)."','".$camp->camp_id."')";
						$this->db->query($query);
						
					}
					
					//if link to source set flag
					if(in_array('OPT_LINK_SOURSE', $camp_opt)){
						add_post_meta ( $id, '_link_to_source', 'yes' );
					}
					
					//if link canonical
					if(in_array('OPT_LINK_CANONICAL', $camp_opt)){
						add_post_meta ( $id, 'canonical_url', $source_link );
					}
					 
					// add featured image
					if (in_array ( 'OPT_REPLACE', $camp_opt )) {
						foreach ( $keywords as $keyword ) {
							
							$keyword = trim($keyword);
							
							if (trim ( $keyword != '' )) {
								$post_content = str_replace ( $keyword, '<a href="' . $camp->camp_replace_link . '">' . $keyword . '</a>', $post_content );
							}
						}
					}
					
		
					if (in_array ( 'OPT_THUMB', $camp_opt )) {
						
						
						//if force og_img
						if(in_array('OPT_FEEDS_OG_IMG', $camp_opt) && isset($img['og_img'])){
						
							if(in_array('OPT_FEEDS_OG_IMG_REVERSE', $camp_opt)  && stristr($post_content, '<img')){
								echo '<br>og:image found but will be skipped';
								//here the image contains a first image and og:image should skipped
								
								//set an og:image variable so it get appended to the end of found images. If width check is active and all images on post are not wide enough
								$og_image = $img['og_img'];
								
							}else{
								$srcs = array($img['og_img']) ;
							}
							
							
						
						
						}
						
						//if youtube set thumbnail to video thum
						if($camp_type == 'Youtube' || $camp_type == 'Vimeo' ){
							//set youtube/vimeo image as featured image
							
							
							//check if maxres exists
							if( stristr( $vid['vid_img'] , 'hqdefault' ) ){
								$maxres = str_replace('hqdefault', 'maxresdefault', $vid['vid_img']) ;

								$maxhead = wp_remote_head($maxres);
								
								if(! is_wp_error($maxres) && $maxhead['response']['code'] == 200 ){
									$vid['vid_img'] = $maxres;
								}
								
							}
							
							
							$srcs=array($vid['vid_img']);
							
							echo '<br>Vid Thumb:'.$vid['vid_img'];
						}elseif($camp_type == 'SoundCloud'){
							
							$srcs = array($img['item_thumbnail']);
							
						}elseif(isset($srcs) && count($srcs) > 0 ){
							
						}else{
							// extract first image
							preg_match_all ( '/<img [^>]*src[\s]*=[\s]*["|\']([^"|\']+)/i', stripslashes ( $post_content ), $matches );
							$srcs = $matches [1];
							
							if(isset($og_image)){
								$og_arr = array();
								$og_arr[] = $og_image;
								$srcs = array_merge($srcs,$og_arr);
							}
								
							
							
						}
						 
						
						//may be a readability missed the image on the content get it from summary ?
						if( count($srcs) == 0 &&  $camp_type == 'Feeds' && in_array('OPT_FULL_FEED', $camp_opt) ){
							echo '<br>Featured image missing on full content searching it on feed instead';
							preg_match_all ( '/<img [^>]*src=["|\']([^"|\']+)/i', stripslashes ( $article['original_content'] ), $matches );
							$srcs = $matches [1];
							
							if(count($srcs) == 0){
								echo '<br>No image found at the feed summary';
								
								if( trim($img['og_img']) != '' ){
									echo '<br>Graph image thumb found';
									$srcs = array($img['og_img']);
								}
								
							}
							 	
						}
						
						
						
						//No featured image found let's check if random image list found
						if ( count($srcs) == 0 && in_array ( 'OPT_THUMB_LIST', $camp_opt )) {
							echo '<br>Trying to set random image as featured image';
							
							$cg_thmb_list=$camp_general['cg_thmb_list'];
							
							$cg_imgs = explode("\n", $cg_thmb_list);
							$cg_imgs = array_filter($cg_imgs);
							$cg_rand_img = trim( $cg_imgs [rand(0,count($cg_imgs)-1)]);
							
							//validate image
							if(trim( $cg_rand_img)!='' ){
								$srcs=array($cg_rand_img);
							}
							  
						}
						
						//if foce using thumb list
						if( in_array('OPT_THUMB_LIST_FORCE', $camp_opt) && in_array ( 'OPT_THUMB_LIST', $camp_opt ) ){
							
							echo '<br>Force using image from set list';
							
							$cg_thmb_list=$camp_general['cg_thmb_list'];
								
							$cg_imgs = explode("\n", $cg_thmb_list);
							$cg_imgs = array_filter($cg_imgs);
							
							
							
							$cg_rand_img = trim( $cg_imgs [rand(0,count($cg_imgs)-1)]);
		
							
							//validate image
							if(trim( $cg_rand_img)!='' ){
								$srcs=array($cg_rand_img);
							}
							
						}
						 
						//check srcs size to skip small images
						if(count($srcs) >0 && in_array('OPT_THUMB_WIDTH_CHECK', $camp_opt)){
							
							$cg_minimum_width = 0;
							$cg_minimum_width = $camp_general['cg_minimum_width'];

							if(!  (is_numeric( $cg_minimum_width ) && $cg_minimum_width > 0 ) ){
								$cg_minimum_width = 100;
							}
							
							$n=0;
							$upload_dir = wp_upload_dir ();
							
							foreach($srcs as $current_img){
								
								echo '<br>Candidate featured image: '.$current_img ;
								
								if(stristr($current_img, 'data:image') && stristr($current_img, 'base64,')){
									
									$ex = explode('base64,', $current_img);
									
									$image_data = base64_decode($ex[1]);
									
									
								}else{
								
									//curl get
									$x='error';
									curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
									curl_setopt($this->ch, CURLOPT_URL, trim($current_img));
									$image_data=curl_exec($this->ch);
									$x=curl_error($this->ch);
									
								}
								
							 	
									
								if(trim($image_data) != ''){
									
									//let's save the file
									if (wp_mkdir_p ( $upload_dir ['path'] ))
										$file = $upload_dir ['path'] . '/' . 'temp_wp_automatic';
									else
										$file = $upload_dir ['basedir'] . '/' . 'temp_wp_automatic';
									
									file_put_contents ( $file, $image_data );
		
									$size = getimagesize($file);
									  
									if($size != false){
										
										if($size[0] >$cg_minimum_width ){
											echo '<-- Valid width is '.$size[0] . ' larget than '.$cg_minimum_width   ;
											break;
										}else{
											echo '<-- width is too low '.$size[0];
											unset($srcs[$n]);
										}
										
									}else{
										echo '<--size verification failed';
										unset($srcs[$n]);
									}
									
									
								}else{
									echo '<--no content ';
									unset($srcs[$n]);
								}
								
								$n++;
							}
						
						}		
						
					 
						//setting the thumb
						if (count ( $srcs ) > 0) {
							
							$src = reset($srcs);
							
							$image_url = $src;
							 
							$this->log ( 'Featured image', '<a href="' . $image_url . '">' . $image_url . '</a>' );
							
							echo '<br>Featured image src: '.$image_url;
							
							// set thumbnail
							$upload_dir = wp_upload_dir ();
							
							//img host
							$imghost = parse_url ( $image_url, PHP_URL_HOST );
								
							if(stristr($imghost, 'http://')){
								$imgrefer=$imghost;
							}else{
								$imgrefer = 'http://'.$imghost;
							}
		
							//empty referal
							if( ! in_array('OPT_CACHE_REFER_NULL', $camp_opt) ){
								curl_setopt ( $this->ch, CURLOPT_REFERER, $imgrefer );
							}else{
								curl_setopt ( $this->ch, CURLOPT_REFERER, '' );
							}
							
							
							if( stristr($image_url, 'base64,')  ){
								
								$filename = time('now');
								
							
							}else{
								
								//decode html entitiies
								$image_url = html_entity_decode($image_url);
								
								if(stristr($image_url, '%') ) {
									$image_url = urldecode($image_url);
								}
								
								//file name to store
								$filename = basename ( $image_url );
									
									
								if(stristr($image_url ,' ')){
									$image_url = str_replace(' ', '%20', $image_url);
								}
									
							}
							
												
							
							if(!in_array('OPT_THUM_NELO', $camp_opt) || stristr($image_url, 'base64,')){
							
								if(  stristr($image_url, 'base64,')  ){
									$ex = explode('base64,', $current_img);
									$image_data = base64_decode($ex[1]);
									
									//set fileName extention .png, .jpg etc
									preg_match('{data:image/(.*?);}', $image_url ,$ex_matches);
									$image_ext = $ex_matches[1];
									
									if(trim($image_ext) != ''){
										$filename = $filename .'.'.$image_ext;
										
										echo '<br>Fname:'.$filename;
										
										
									}
									
								}else{
									

									//get image content
									$x='error';
									curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
									curl_setopt($this->ch, CURLOPT_URL, trim( html_entity_decode($image_url) ) );
									$image_data=$this->curl_exec_follow($this->ch);
									
									$x=curl_error($this->ch);
									
									
								}
								 
								 
								if(trim($image_data) != ''){
									
			 						//check if already saved
			 						
									$image_data_md5 = md5($image_data);
									
									$is_cached = $this->is_cached($image_url , $image_data_md5);
									if( $is_cached != false ){
										echo '<--already cached' ;
										$file = $this->cached_file_path;
										$guid = $is_cached; 
			 						}else{ 
									 
										
										if (stristr ( $filename, '?' )) {
											$farr = explode ( '?', $filename );
											$filename = $farr [0];
										}
										
										//pagepeeker fix
										if(stristr($image_url, 'pagepeeker')){
											$filename = md5($filename).'.jpg';
										}
										
										if (wp_mkdir_p ( $upload_dir ['path'] ))
											$file = $upload_dir ['path'] . '/' . $filename;
										else
											$file = $upload_dir ['basedir'] . '/' . $filename;
											
											// check if same image name already exists
										if (file_exists ( $file )) {
											
											 //get the current saved one to check if identical
											$already_saved_image_link=$upload_dir ['url'] . '/' . $filename;
				
											//curl get
											$x='error';
											$url=$already_saved_image_link;
											curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
											curl_setopt($this->ch, CURLOPT_URL, trim($url));
											 
											$exec=curl_exec($this->ch);
											 
											if(trim($exec) == trim($image_data)){
												$idential = true;
												echo '<br>Featured image already exists with same path.. using it';
											}else{
												echo '<br>Featured image exists with same path but not identical.. saving  ';
												
												$filename = time ( 'now' ) . '_' . $filename;
												
											}
											 
										}
										
										
										//saving image 
										if(! isset($idential )){
											if (wp_mkdir_p ( $upload_dir ['path'] ))
												$file = $upload_dir ['path'] . '/' . $filename;
											else
												$file = $upload_dir ['basedir'] . '/' . $filename;
											
											$f=file_put_contents ( $file, $image_data );
										}
										 
										$guid = $upload_dir['url'] . '/' . basename( $filename );
										
										$this->img_cached($image_url, $guid,$image_data_md5,$file);
									
			 						}//not cached	
									
									//atttatchment check if exists or not
									global  $wpdb;
									
									
									$query = "select * from $wpdb->posts where guid = '$guid'";
									$already_saved_attachment = $wpdb->get_row($query);
									 
									if(isset($already_saved_attachment->ID)){
										$attach_id = $already_saved_attachment->ID;
										 
									}else{
										
			
										$wp_filetype = wp_check_filetype ( $filename, null );
										
										if($wp_filetype['type'] == false){
											$wp_filetype['type'] = 'image/jpeg';
										}
										
											
										$attachment = array (
												'guid'           =>  $guid,
												'post_mime_type' => $wp_filetype ['type'],
												'post_title' => sanitize_file_name ( $filename ),
												'post_content' => '',
												'post_status' => 'inherit'
										);
										$attach_id = wp_insert_attachment ( $attachment, $file, $post_id );
										require_once (ABSPATH . 'wp-admin/includes/image.php');
										$attach_data = wp_generate_attachment_metadata ( $attach_id, $file );
										wp_update_attachment_metadata ( $attach_id, $attach_data );
										
									}
									 
			
								
									set_post_thumbnail ( $post_id, $attach_id );
									
									echo ' <-- thumbnail set successfully';
									
									//if hide first image set the custom field 
									if(in_array('OPT_THUMB_STRIP', $camp_opt)){
										update_post_meta ( $post_id, 'wp_automatic_remove_first_image', 'yes' );
									}
									
								}else{
									echo ' <-- can not get image content '.$x;
								}
							
							}else{//nelo
								//setting custom field for nelo image
								echo '<br>Setting the featured image custom field for nelio plugin'; 
								update_post_meta($id, '_nelioefi_url', $image_url);	
							}	
							
							
						} else {
							
							//currently no images in the content 
							$this->log ( 'Featured image', 'No images found to set as featured' );
				
						}
					} // thumbnails
					  
					// tags
					if (in_array ( 'OPT_TAG', $camp_opt )) {
						
					
						if(in_array('OPT_TAXONOMY_TAG', $camp_opt)){
								
							wp_set_post_terms( $id, $keywords , trim($camp_general['cg_tag_tax']), true );
								
						}else{
							wp_set_post_tags ( $id, $keywords, true );
						}
					
					}
					
					//youtube tags and comments
					if($camp_type == 'Youtube'   ){
						
						//tags
						if(in_array('OPT_YT_TAG', $camp_opt)){
							if(trim($this->used_tags) != ''){
								
								
								if(in_array('OPT_TAXONOMY_TAG', $camp_opt)){
								
									wp_set_post_terms( $id, $this->used_tags , trim($camp_general['cg_tag_tax']), true );
								
								}else{
									wp_set_post_tags ( $id, $this->used_tags, true );
								}
								
								
								
								
							}	
						}
						
						
						
						//comments
						if(in_array('OPT_YT_COMMENT', $camp_opt) ){
							echo '<br>Trying to post comments';
							
							//get id
							$temp=explode('v=', $this->used_link);
							$vid_id=$temp[1] ;
							
							$wp_automatic_yt_tocken=trim(get_option('wp_automatic_yt_tocken',''));
							
							$maxResults = rand(20,50);
							
							$comments_link="https://www.googleapis.com/youtube/v3/commentThreads?maxResults=$maxResults&part=snippet&videoId=".$vid_id."&key=$wp_automatic_yt_tocken";
							
							//curl get
							$x='error';
							$url=$comments_link;
							curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
							curl_setopt($this->ch, CURLOPT_URL, trim($url));
						 	$exec=curl_exec($this->ch);
 	 
						 	
							$x=curl_error($this->ch);
						 	
							if(trim($x) != '') echo '<br>'.$x;
							
							if(trim($exec) !=''){
								
								if( stristr($exec, 'items')){
									$comments_array=json_decode($exec);
									
									$entry=$comments_array->items ;
									
									if(count($entry) == 0){
										echo '<br>No comments found';
									}else{
										echo  '<br>Found '.count($entry). ' comment to post';
										 
										foreach($entry as $comment ){
											
											$comment = $comment->snippet->topLevelComment->snippet;
											
											$commentText= $comment->textDisplay;
											$commentAuthor= $comment->authorDisplayName;
											$commentUri= $comment->authorChannelUrl;
											
		 									$time = current_time('mysql');
											
		 									if(trim($commentText) != '' ){
												$data = array(
														'comment_post_ID' => $id,
														'comment_author' => $commentAuthor,
														'comment_author_email' => '',
														'comment_author_url' => $commentUri,
														'comment_content' => $commentText,
														'comment_type' => '',
														'comment_parent' => 0,
														 
														'comment_author_IP' => '127.0.0.1',
														'comment_agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
														'comment_date' => $time,
														'comment_approved' => 1,
												);
												
												wp_insert_comment($data);
		 									}
		 									
										}
										
									}
									
								}else{
									echo '<br>could not find comments';
								}
								
							}else{
								echo '<br>No valid comments feed';
							}
							
						}
						
					}
					
					// AFTER POST SPECIFIC
					if ($camp_type == 'Flicker') {
						if (in_array ( 'OPT_FL_TAG', $camp_opt )) {
							
							if(in_array('OPT_TAXONOMY_TAG', $camp_opt)){
							
								wp_set_post_terms( $id, $img ['img_tags'] , trim($camp_general['cg_tag_tax']), true );
							
							}else{
								wp_set_post_tags ( $id, $img ['img_tags'], true );
							}
							
							
						}
					}
					
					// AFTER POST SPECIFIC SoundCloud
					if ($camp_type == 'SoundCloud') {
						
						//tags
						if (in_array ( 'OPT_SC_TAG', $camp_opt )) {
							
							$item_tags = $img['item_tags'];
							
							//extract tags with multiple words 
							preg_match_all('{".*?"}', $item_tags, $multiple_tags_matches);
							
							$multiple_tags_matches = $multiple_tags_matches[0];
							  
							$single_item_tags = $item_tags;
							
							
							foreach ($multiple_tags_matches as $multiple_tag){
								$single_item_tags = str_replace($multiple_tag, '', $single_item_tags);
								$single_item_tags = str_replace('  ', ' ', $single_item_tags);
							}
							
							//remove "
							$multiple_tags_matches = str_replace('"', '', $multiple_tags_matches);
							
							//explode single tags
							$single_item_tags = explode(' ', $single_item_tags);
							
							$all_tags = array_merge($multiple_tags_matches,$single_item_tags);
							$all_tags = array_filter($all_tags);
							$all_tags_comma = implode(',', $all_tags);
							
							 if(trim($all_tags_comma) != ''){
							 	echo '<br>Tags:'.$all_tags_comma;
							 	
							 	if(in_array('OPT_TAXONOMY_TAG', $camp_opt)){
							 	
							 		wp_set_post_terms( $id, $all_tags_comma , trim($camp_general['cg_tag_tax']), true );
							 	
							 	}else{
							 		wp_set_post_tags ( $id, $all_tags_comma, true );
							 	}
							 	
							 	
							 
							 }
							 
						}
						
						//comments
						if(in_array('OPT_SC_COMMENT', $camp_opt)){
							
							$wp_automatic_sc_client= get_option('wp_automatic_sc_client');
							
							if(trim($wp_automatic_sc_client) != ''){
								
								//getting the comment 
								
								$item_id = $img['item_id'];
								
								echo '<br>Fetching comments for tack:'.$item_id;
								
								$commentsCount = rand(20,30);
								
								$api_url = "http://api.soundcloud.com/tracks/$item_id/comments?client_id=$wp_automatic_sc_client&limit=$commentsCount";
								
								//curl get
								$x='error';
								 
								curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
								curl_setopt($this->ch, CURLOPT_URL, trim($api_url));
								$exec=curl_exec($this->ch);
								$x=curl_error($this->ch);
								
								if( stristr($exec, '"comment"')){
									
									$comments_json = json_decode($exec);
									
									echo '<br>Found '.count($comments_json) . ' comments to post.';
									
									$time = current_time('mysql');
									
									foreach ($comments_json  as $new_comment){
										
										if($new_comment->kind == 'comment'){
											
											$data = array(
													'comment_post_ID' => $id,
													'comment_author' => $new_comment->user->username,
													'comment_author_email' => '',
													'comment_author_url' => $new_comment->user->permalink_url,
													'comment_content' => $new_comment->body,
													'comment_type' => '',
													'comment_parent' => 0,
											
													'comment_author_IP' => '127.0.0.1',
													'comment_agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
													'comment_date' => $time,
													'comment_approved' => 1,
											);
												
											wp_insert_comment($data);
											
											
										}
										
									}
									
									
									
									
								}else{
									echo '<br>No comments found';
								}
								 
							}
							
						}
						
					}
					
					//After post facebook
					if($camp_type == 'Facebook'){
						if(in_array('OPT_FB_COMMENT', $camp_opt)){
							
							//trying to post FB comments
							echo '<br>Posting FB comments as comments :'.$img['post_id'];
							
							$cg_fb_access = get_option('wp_automatic_fb_token','');
							
							//curl get
							$x='error';
							$url='https://graph.facebook.com/v2.5/'.$img['post_id'].'/comments?access_token='.$cg_fb_access.'&summary=1&filter=toplevel&fields=message,id,from,message_tags,created_time';
							
							
							curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
							curl_setopt($this->ch, CURLOPT_URL, trim($url));
 							$exec=curl_exec($this->ch);
							$x=curl_error($this->ch);
							
							if(stristr($exec, 'data')){
								
								$comments_json = json_decode($exec);
								$comments = $comments_json->data;
								
								$added = 0 ;
								$time = current_time('mysql');
								
								foreach($comments as $comment){
									
									if(! is_array($comment->message_tags)){
										
										
										$commentText= $comment->message;
										$commentAuthor= $comment->from->name;
										 	
										$commentAuthorID= $comment->from->id;
										$commentUri= "https://facebook.com/". $commentAuthorID;
										
										if(in_array('OPT_ORIGINAL_FB_TIME', $camp_opt) ){
											
											$time = date('Y-m-d H:i:s', strtotime($comment->created_time) );
										}
											
										
										if(trim($commentText) != '' ){
											$data = array(
													'comment_post_ID' => $id,
													'comment_author' => $commentAuthor,
													'comment_author_email' => '',
													'comment_author_url' => $commentUri,
													'comment_content' => $commentText,
													'comment_type' => '',
													'comment_parent' => 0,
														
													'comment_author_IP' => '127.0.0.1',
													'comment_agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
													'comment_date' => $time,
													'comment_approved' => 1,
											);
										
											wp_insert_comment($data);
										}
										
										
										
										$added++;
									}
									
								}
								
								
								echo '<br>'.$added . ' comments to post';
								
								 
								
								
							}else{
								echo '<br>No valid reply for the comments request';
							}
 
							
						}
					}
					
					//After post vimeo 
					if($camp_type == 'Vimeo'){
						
						if(in_array('OPT_VM_TAG', $camp_opt)){
								
							if(trim($vid['vid_tags']) != ''){
								
								if(in_array('OPT_TAXONOMY_TAG', $camp_opt)){
								
									wp_set_post_terms( $id, $keywords , $vid['vid_tags'], true );
								
								}else{
									wp_set_post_tags ( $id, $vid['vid_tags'], true );
								}
								
								
								
								
							}
						}
						
					}
					
					if($camp_type == 'Instagram'){
					
						if(in_array('OPT_IT_TAGS', $camp_opt)){
					
						 
							if(trim($img['item_tags']) != ''){
								
								echo '<br>Setting tags:'.$img['item_tags'];
								
								if(in_array('OPT_TAXONOMY_TAG', $camp_opt)){
								
									wp_set_post_terms( $id, $keywords , $img['item_tags'] , true );
								
								}else{
									wp_set_post_tags ( $id, $img['item_tags'], true );
								}
								
								
							}
						}
						
						
						//comments
						if(in_array('OPT_IT_COMMENT', $camp_opt) ){
							
							echo '<br>Trying to post comments';
							
							$time = current_time('mysql');
		
							$comments = $img['item_comments'];
		 						
							if(count($comments) > 0){
						
								  
									 
										echo  '<br>Found '.count($comments). ' comment to post';
											
										foreach($comments as $comment ){
												
											$commentText= $comment->text;
											$commentAuthor= $comment->from->full_name;
											
											if(trim($commentAuthor) == '') $commentAuthor= $comment->from->username;
											
											$commentAuthorID= $comment->author[0]->uri->x;
											$commentUri= "https://instagram.com/". $comment->from->username;
												
											if(in_array('OPT_IT_DATE', $camp_opt) ){
												$time = date('Y-m-d H:i:s',$comment->created_time);
											} 
											
												
											if(trim($commentText) != '' ){
												$data = array(
														'comment_post_ID' => $id,
														'comment_author' => $commentAuthor,
														'comment_author_email' => '',
														'comment_author_url' => $commentUri,
														'comment_content' => $commentText,
														'comment_type' => '',
														'comment_parent' => 0,
															
														'comment_author_IP' => '127.0.0.1',
														'comment_agent' => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.10) Gecko/2009042316 Firefox/3.0.10 (.NET CLR 3.5.30729)',
														'comment_date' => $time,
														'comment_approved' => 1,
												);
						
												wp_insert_comment($data);
											}
						
										}
						
									 
										
							 
						
							}else{
								echo '<br>No comments found';
							}
								
						}
					
					
					
					}
					
					//After ebay 
					if(in_array('OPT_EB_REDIRECT_END', $camp_opt)){
						echo '<br>Setting expiry date: '.$img['item_end_date'];
						
						$expiry_date = strtotime( $img['item_end_date'] );
						
						add_post_meta($id, 'wp_automatic_redirect_date', $expiry_date);
						add_post_meta($id, 'wp_automatic_redirect_link', $camp_general['cg_eb_redirect_end']);
 						
					}
					
					if(in_array('OPT_EB_TRASH', $camp_opt)){
						echo '<br>Setting trash date: '.$img['item_end_date'];
					
						$expiry_date = strtotime( $img['item_end_date'] );
					
						add_post_meta($id, 'wp_automatic_trash_date', $expiry_date);
					 		
					}
					
					//setting post tags
					$post_tags=array();
					
					if(in_array('OPT_ADD_TAGS',$camp_opt ) ){
						
						$post_tags = array_filter( explode("\n", $camp_general['cg_post_tags']));
						
						$max = $camp_general['cg_tags_limit'];
						if(! is_numeric($max)) $max= 100;
						
						if(in_array('OPT_RANDOM_TAGS', $camp_opt)  && count($post_tags) > $max ){
							
							
							$rand_keys = array_rand($post_tags,$max);
							
							if(is_array($rand_keys)) {
								
								
								$temp_tags = array();
								foreach ($rand_keys as $key){
									$temp_tags[] = $post_tags[$key];
								}
								
							}else{
								
								//single value selected like 0
								
								$temp_tags[] = $post_tags[$rand_keys] ;
							}
							
							$post_tags = $temp_tags;
								
						}
							 
					}
					
					
		
					if(in_array('OPT_ORIGINAL_TAGS', $camp_opt)){
						$new_tags = explode(',', $img['tags']);
						
						if(count($new_tags) > 0 ){
							$post_tags = array_merge($post_tags,$new_tags);
						}
						
					}
					
					
				 
					if(count($post_tags) >0){
						echo '<br>Setting ' . count($post_tags) .' post tags as tags';
					
						if(in_array('OPT_TAXONOMY_TAG', $camp_opt)){
							
							wp_set_post_terms( $id, implode(',', $post_tags), trim($camp_general['cg_tag_tax']), true );
							
						}else{
							wp_set_post_tags ( $id, implode(',', $post_tags) , true );
						}
						
						
					
					
					
					}
					
					//amazon woocommerce integration
					if($camp_type == 'Amazon' && $camp->camp_post_type == 'product'){
						
						$camp_post_custom_k = array_merge ( array('_regular_price','_price','_visibility', '_product_url','_button_text','_product_type'),$camp_post_custom_k);
						$camp_post_custom_v = array_merge ( array('[price_numeric]','[price_numeric]','visible','[product_link]','buy now','external'),$camp_post_custom_v);
						
						
						 
						wp_set_object_terms ($id, 'external', 'product_type');
						
						
						
					}elseif($camp_type == 'eBay' && $camp->camp_post_type == 'product'){
						
						$camp_post_custom_k = array_merge ( $camp_post_custom_k , array('_regular_price','_price','_visibility', '_product_url','_button_text','_product_type'));
						$camp_post_custom_v = array_merge ( $camp_post_custom_v , array('[item_price]','[item_price] ','visible','[item_link]','buy now','external'));
							
						wp_set_object_terms ($id, 'external', 'product_type');
						
					}elseif( $camp->camp_post_type == 'product' ){
						
							$camp_post_custom_k = array_merge ( $camp_post_custom_k , array('_visibility'));
							$camp_post_custom_v = array_merge ( $camp_post_custom_v , array('visible'));
								
							wp_set_object_terms ($id, 'external', 'product_type');
								
						
					}
					
					//TrueMag integration 
					if( ($camp_type == 'Youtube' || $camp_type == 'Vimeo')  && defined('PARENT_THEME')     ){
						
						if(PARENT_THEME =='truemag' || PARENT_THEME =='newstube' ){
						
							echo '<br>TrueMag/NewsTube theme exists adabting config..';
							$camp_post_custom_k = array_merge ( $camp_post_custom_k , array('tm_video_url','_count-views_all'));
							$camp_post_custom_v = array_merge ( $camp_post_custom_v , array('[source_link]','[vid_views]'));
						 
							//adding likes n dislikes
							$vid_likes =  $img['vid_likes'];
							$vid_dislikes = $img['vid_dislikes'];
							 
							//adding likes 
							if($vid_likes > 0 ){
								
								$query = "INSERT INTO {$this->db->prefix}wti_like_post SET ";
								$query .= "post_id = '" . $id . "', ";
								$query .= "value = '$vid_likes', ";
								$query .= "date_time = '" . date( 'Y-m-d H:i:s' ) . "', ";
								$query .= "ip = ''";
								$this->db->query($query);
							}
							
							if($vid_dislikes > 0 && $camp_type == 'Youtube'  ){
							
								$query = "INSERT INTO {$this->db->prefix}wti_like_post SET ";
								$query .= "post_id = '" . $id . "', ";
								$query .= "value = '-$vid_dislikes', ";
								$query .= "date_time = '" . date( 'Y-m-d H:i:s' ) . "', ";
								$query .= "ip = ''";
								$this->db->query($query);
							}
							
							
						
						}
		 			}
					
		  				 	
					//replacing tags 
					$camp_post_custom_v = implode ( '****', $camp_post_custom_v );
					foreach ( $img as $key => $val ) {
						if(! is_array($val)){
							$camp_post_custom_v = str_replace ( '[' . $key . ']', $val, $camp_post_custom_v );
						}
					}
					$camp_post_custom_v = explode ( '****', $camp_post_custom_v );
					
					
					//NewsPaper theme integration
					if( ($camp_type == 'Youtube' || $camp_type == 'Vimeo') && function_exists('td_bbp_change_avatar_size')){
						echo '<br>NewsPaper theme found integrating..';
					
					
					
						$td_video = array();
						$td_video['td_video'] = $img['vid_url'];
						$td_video['td_last_video'] = $img['vid_url'];
					
							
					
						$camp_post_custom_k[] = 'td_post_video';
						$camp_post_custom_v[] =  $td_video;
					
						//format
						echo '<br>setting post format to Video';
						set_post_format($id,  'video' );
					
						//custom field
					
					}
						
					
					
					// adding custom filds
					$in = 0;
					if (count ( $camp_post_custom_k ) > 0) {
						
					 	
						foreach ( $camp_post_custom_k as $key ) {
							if (trim ( $key ) != '' & trim ( $camp_post_custom_v [$in] != '' )) {
								echo '<br>Setting custom field ' . $key  ;
								
								 	//serialized arrays
								if(is_serialized($camp_post_custom_v [$in])) $camp_post_custom_v [$in] = unserialize($camp_post_custom_v [$in]);
								
								update_post_meta ( $id, $key, $camp_post_custom_v [$in] );
							}
							
							$in ++;
						}
					}
					
					//setting post format OPT_FORMAT 
					if (in_array ( 'OPT_FORMAT', $camp_opt )) {
						echo '<br>setting post format to '.$camp_general['cg_post_format'];
						set_post_format($id, stripslashes($camp_general['cg_post_format']) );
					}elseif ( ($camp_type == 'Youtube' || $camp_type == 'Vimeo') && defined( 'PARENT_THEME')    ){
						
						if(PARENT_THEME =='truemag' || PARENT_THEME =='newstube'  ){
							echo '<br>setting post format to Video';
							set_post_format($id,  'video' );
						}
					}
					
					 
					
					if(in_array('OPT_PREVIEW_EDIT',$wp_automatic_options)){
						$plink =  get_edit_post_link(  $id );
					}else{
						$plink =  get_permalink ( $id ) ;
					}
					
					$plink = str_replace('&amp;', '&', $plink) ;
					 
					
					$display_title = get_the_title ( $id );
					
					if(trim($display_title) == '') $display_title = '(no title)';
					
					$now = date ( 'Y-m-d H:i:s' );
					$now = get_date_from_gmt($now);
					 
					echo '<br>New Post posted: <a target="_blank" class="new_post_link" time="' . $now . '" href="' .  $plink . '"> ' . $display_title . '</a>';
					$this->log ( 'Posted:' . $camp->camp_id, 'New post posted:<a href="' . $plink . '">' . get_the_title ( $id ) . '</a>' );
					exit ();
					
					print_r ( $ret );
				} // if title
			} // end function
			
			function fire_proxy() {
				echo '<br>Proxy Check Fired';
				$proxies = get_option ( 'wp_automatic_proxy' );
				if (stristr ( $proxies, ':' )) {
					echo '<br>Proxy Found lets try';
					// listing all proxies
					
					$proxyarr = explode ( "\n", $proxies );
					
					foreach ( $proxyarr as $proxy ) {
						if (trim ( $proxy ) != '') {
							
							if (substr_count ( $proxy, ':' ) == 3) {
								echo '<br>Private proxy found .. using authentication';
								$proxy_parts = explode ( ':', $proxy );
								
								$proxy = $proxy_parts [0] . ':' . $proxy_parts [1];
								$auth = $proxy_parts [2] . ':' . $proxy_parts [3];
								
								curl_setopt ( $this->ch, CURLOPT_PROXY, trim ( $proxy ) );
								curl_setopt ( $this->ch, CURLOPT_PROXYUSERPWD, $auth );
							} else {
								curl_setopt ( $this->ch, CURLOPT_PROXY, trim ( $proxy ) );
							}
							
							echo "<br>Trying using proxy :$proxy";
							
							curl_setopt ( $this->ch, CURLOPT_HTTPPROXYTUNNEL, 1 );
							
							curl_setopt ( $this->ch, CURLOPT_URL, 'www.bing.com/search?count=50&intlF=1&mkt=En-us&first=0&q=test' );
							// curl_setopt($this->ch, CURLOPT_URL, 'http://whatismyipaddress.com/');
							$exec = curl_exec ( $this->ch );
							
							if (curl_error ( $this->ch )) {
								echo '<br>Curl Proxy Error:' . curl_error ( $this->ch );
							} else {
								
								if (stristr ( $exec, 'It appears that you are using a Proxy' ) || stristr ( $exec, 'excessive amount of traffic' )) {
									echo '<br>Proxy working but captcha met let s skip it';
								} elseif (stristr ( $exec, 'microsoft.com' )) {
									
									// succsfull connection here
									// echo curl_exec($this->ch);
									// reordering the proxy
									$proxies = str_replace ( ' ', '', $proxies );
									$proxies = str_replace ( $proxy, '', $proxies );
									$proxies = str_replace ( "\n\n", "\n", $proxies );
									$proxies = "$proxy\n$proxies";
									// echo $proxies;
									update_option ( 'wp_automatic_proxy', $proxies );
									
									echo '<br>Connected successfully using proxy :' . $proxy;
									
									return true;
								} else {
								}
							}
						}
					}
					
					// all proxies not working let's call proxyfrog for new list
					
					// no proxyfrog list
					$this->unproxyify ();
					
					// proxifing the connection
				}else{
					echo '..No proxies';
				}
			}
			
			/*
			 * ---* Clear proxy function ---
			 */
			function unproxyify() {
				// clean the connection
				unset ( $this->ch );
				
				// curl ini
				$this->ch = curl_init ();
				curl_setopt ( $this->ch, CURLOPT_HEADER, 0 );
				curl_setopt ( $this->ch, CURLOPT_RETURNTRANSFER, 1 );
				curl_setopt ( $this->ch, CURLOPT_CONNECTTIMEOUT, 20 );
				curl_setopt ( $this->ch, CURLOPT_TIMEOUT, 30 );
				curl_setopt ( $this->ch, CURLOPT_REFERER, 'http://www.google.com' );
				curl_setopt ( $this->ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.8) Gecko/2009032609 Firefox/3.0.8' );
				curl_setopt ( $this->ch, CURLOPT_MAXREDIRS, 5 ); // Good leeway for redirections.
				curl_setopt ( $this->ch, CURLOPT_FOLLOWLOCATION, 1 ); // Many login forms redirect at least once.
				curl_setopt ( $this->ch, CURLOPT_COOKIEJAR, "cookie.txt" );
			}
			 
			/*
			 * ---* Spin function that calls TBS ---
			 */
			function spin($html) {
				
				
				
				$url = 'http://thebestspinner.com/api.php';
				
				// $testmethod = 'identifySynonyms';
				$testmethod = 'replaceEveryonesFavorites';
				
				// Build the data array for authenticating.
				
				$data = array ();
				$data ['action'] = 'authenticate';
				$data ['format'] = 'php'; // You can also specify 'xml' as the format.
				                          
				// The user credentials should change for each UAW user with a TBS account.
				$tbs_username = get_option ( 'wp_automatic_tbs', '' ); // "gigoftheday@gmail.com"; // Enter your The Best Spinner's Email ID
				$tbs_password = get_option ( 'wp_automatic_tbs_p', '' ); // "nd8da759a40a551b9aafdc87a1d902f3d"; // Enter your The Best Spinner's Password
				$tbs_protected = get_option ('wp_automatic_tbs_protected','');
				
				if(trim($tbs_protected) != ''){
					$tbs_protected = explode("\n", $tbs_protected);
					$tbs_protected = array_filter($tbs_protected);
					$tbs_protected = array_map('trim', $tbs_protected);
					
					$tbs_protected = array_filter($tbs_protected);
					
					$tbs_protected = implode(',', $tbs_protected);
				}
				
				//add , if not exists
				if(! stristr($tbs_protected, ',')  ){
					$tbs_protected = $tbs_protected .',';
				}
				
				//add ad_1, ad_2 , numbers
				 
				$tbs_protected = $tbs_protected . 'ad_1,ad_2';
				
				 
				
				if (trim ( $tbs_username ) == '' || trim ( $tbs_password ) == '') {
					//$this->log ( 'Info', 'No BTS account found , it is highly recommended ' );
					return $html;
				}
				
				$data ['username'] = $tbs_username;
				$data ['password'] = $tbs_password;
				
				// Authenticate and get back the session id.
				// You only need to authenticate once per session.
				// A session is good for 24 hours.
				$output = unserialize ( $this->curl_post ( $url, $data, $info ) );
				
				
				
				if ($output ['success'] == 'true') {
					
					$this->log ( 'TBS', "TBS Login success" );
					echo '<br>TBS Login success';
					// Success.
					$session = $output ['session'];
					
					// Build the data array for the example.
					$data = array ();
					$data ['session'] = $session;
					$data ['format'] = 'php'; // You can also specify 'xml' as the format.
				 
					$data ['protectedterms'] = $tbs_protected ;
					
					//instantiate original html
					$newhtml = $html;
						
					
					//replace nospins with astrics
					preg_match_all('{\[nospin.*?\/nospin\]}s', $html ,$nospins);
					$nospins = $nospins[0];
					
					//remove empty and duplicate
					$nospins = array_filter(array_unique($nospins));
					
					
					//replace nospin parts with astrics
					$i=1;
					foreach ($nospins as $nospin){
						 $newhtml = str_replace($nospin, '['.str_repeat('*', $i).']', $newhtml);
						 $i++;
					}
					
				
					$data ['text'] =   ( html_entity_decode($newhtml) );
					 
				 
					//$data ['text'] = 'test <br> word <a href="http://onetow.com">http://onetow.com</a> ';
					
					$data ['action'] = $testmethod;
					$data ['maxsyns'] = '100'; // The number of synonyms per term.
					
					if ($testmethod == 'replaceEveryonesFavorites') {
						// Add a quality score for this method.
						$data ['quality'] = '1';
					}
					
					 
					// Post to API and get back results.
					$output = $this->curl_post ( $url, $data, $info );
					
				  
					$output = unserialize ( $output );
					
				
					
					// Show results.
					// echo "<p><b>Method:</b><br>$testmethod</p>";
					// echo "<p><b>Text:</b><br>$data[text]</p>";
					
					if ($output ['success'] == 'true') {
						$this->log ( 'TBS', "TBS Successfully spinned the content" );
					
						
						//replace the astrics with nospin tags 
						if( count($nospins) > 0 ){
							
							$i = 1 ;
							
							foreach($nospins as $nospin){
		
								$output ['output'] = str_replace('['.str_repeat('*', $i).']', $nospin, $output ['output']);
								
								$i++;
							}
							
							 
						}
						
		 				
						echo '<br>TBS Successfully spinned the content';
						return $output ['output'];
					} else {
						
						
						$this->log ( 'error', "TBS Returned an error:$output[error]" );
						echo "TBS Returned an error:$output[error]";
						return $html;
					}
				} else {
					// There were errors.
					echo "<br>TBS returned an error : $output[error]";
					$this->log ( 'error', "TBS returned an error : $output[error]" );
					return $html;
				}
			} // end function
			
			/*
			 * gtranslte function
			 */
			function gtranslate($title, $content, $from, $to , $translationMethod = 'microsoftTranslator') {
				
				
			   // Verify API data
			   if($translationMethod == 'microsoftTranslator'){
			   	
				   	$wp_automatic_mt_secret = trim(get_option('wp_automatic_mt_secret',''));
				   	$wp_automatic_mt_id = trim(get_option('wp_automatic_mt_id',''));
				   	
				   	if(trim($wp_automatic_mt_secret) == ''){
				   		echo '<br><span style="color:red">Microsoft translator settings required. Visit the plugin settings and set it.</span>';
				   		return array($title,$content);
				   	}
				   	
				   	$titleSeparator = '[19459000]';
			   	
			   }else{
			   	
			   	     $titleSeparator = '##########';
			   	     		
			   } 
	           
			   // Fix Norwegian language Translation 
			   if($from == 'nor') $from = 'no';
			   if($to == 'nor') $to = 'no';
			   
			   // Report Translate
			   echo '<br>Translating from '.$from . ' to '.$to . ' using '.$translationMethod;
				
			   // Concat title and content in one text
				$text = $title . $titleSeparator . $content;
				
				//decode html for chars like &euro;  
				$text = html_entity_decode($text);
			
				// STRIP html and links
				preg_match_all ( "/<[^<>]+>/is", $text, $matches, PREG_PATTERN_ORDER );
				$htmlfounds = array_filter( array_unique($matches [0]));
				$htmlfounds[] = '&quot;'; 

				//<!-- <br> -->
				preg_match_all ( "/<\!--.*?-->/is", $text, $matches2, PREG_PATTERN_ORDER );
				$newhtmlfounds = $matches2[0];
				
				$htmlfounds=array_merge($htmlfounds,$newhtmlfounds);
				
			 	$start = 19459001;
				foreach ( $htmlfounds as $htmlfound ) {
					$text = str_replace ( $htmlfound, '[' . $start . ']', $text );
					$start++;
				}
			 	
				
				// Check Translation Method and use it
				
				if( $translationMethod == 'googleTranslator' ){
				
					try {
					
						// Google Translator Class
						require_once 'inc/translator.Google.php';
					
						// Google Translator Object
						$GoogleTranslator = new GoogleTranslator($this->ch);
					
						// Translate Method
						$translated = $GoogleTranslator->translateText($text, $from, $to);
					 
					} catch (Exception $e) {
					
						echo 'Exception:'.$e->getMessage();
						
						$this->translationSuccess = false ;
						
						return array($title,$content);
					}
						
						
			    }else{
				 	
			    	 // Translating using Microsoft translator
					 require_once 'inc/translator.Microsoft.php';
					 
					 $MicrosoftTranslator = new MicrosoftTranslator($this->ch);
					 
					 try {
					 
					 	// Generate access token
					 	$accessToken = $MicrosoftTranslator->getToken($wp_automatic_mt_id, $wp_automatic_mt_secret);
					 	 
					 	echo '<br>Translated text chars: '. $this->chars_count($text);
					 	 
					 	$translated = $MicrosoftTranslator->translateWrap($text, $from, $to);
					 	
					 } catch (Exception $e) {
					 	
					 	echo '<br>Translation error:'.$e->getMessage();
					 	
					 	$this->translationSuccess = false ;
					 	
					 	return array($title,$content);
					 	
					 }
					 	
				 } 
				
				 // Fix broken ] 19459
				 $translated = preg_replace('{]\s*?1945}' , '[1945', $translated);
				 
				 // Fix broken Add Comment 19459012]
				 $translated = preg_replace('{ 19459(\d*?)]}' , ' [19459$1]', $translated);
				 
				 // Fix [[1945
				 $translated = str_replace('[ [1945', '[1945', $translated);
				 
				 file_put_contents( dirname(__FILE__) .'/test.txt' , $translated);
				  
				 // Grab all replacements with **
				 preg_match_all('{\[.*?\]}', $translated,$brackets);
				 
				 $brackets = $brackets[0];
				 $brackets = array_unique($brackets);
				 	
				 	
				 foreach ($brackets as $bracket){
				 	if(stristr($bracket, '19')){
				 			
				 		$corrrect_bracket = str_replace(' ', '', $bracket);
				 		$corrrect_bracket = str_replace('.', '', $corrrect_bracket);
				 		$corrrect_bracket = str_replace(',', '', $corrrect_bracket);
				 			
				 		$translated = str_replace($bracket, $corrrect_bracket, $translated);
				 
				 	}
				 }
				 
				 
				 
		   		// check if successful translation contains ***
				if (stristr ( $translated, $titleSeparator )) {
					
					$this->translationSuccess = true ;
					 
					// restore html tags
					$start = 19459001;
					foreach ( $htmlfounds as $htmlfound ) {
						$translated = str_replace ( '[' . $start . ']', $htmlfound, $translated );
						$start ++;
					}
					
					 
					$contents = explode ( $titleSeparator, $translated );
					$title = $contents [0];
					$content = $contents [1];
				} else {
					
					$this->translationSuccess = false ;
					
					echo '<br>Translation failed ';
					
					//echo $translated;
					
				}
				
				return array (
						$title,
						$content 
				);
			}
			function curl_post($url, $data, &$info) {
				$ch = curl_init ();
				
				 
				curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
				curl_setopt($ch, CURLOPT_TIMEOUT,20);
				curl_setopt ( $ch, CURLOPT_URL, $url );
				curl_setopt ( $ch, CURLOPT_POST, true );
				curl_setopt ( $ch, CURLOPT_POSTFIELDS, $this->curl_postData ( $data ) );
				curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, true );
				curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
				curl_setopt ( $ch, CURLOPT_REFERER, $url );
				$html = trim ( curl_exec ( $ch ) );
				
				print_r(curl_error($ch));
				 
				return $html;
			}
			function curl_postData($data) {
				$fdata = "";
				foreach ( $data as $key => $val ) {
					$fdata .= "$key=" . urlencode ( $val ) . "&";
				}
				
				return $fdata;
			}
			
			/*
			 * ---* update cb categories ---
			 */
			function update_categories() {
				// Get
				$x = 'error';
				while ( trim ( $x ) != '' ) {
					$url = 'http://www.clickbank.com/advancedMarketplaceSearch.htm';
					curl_setopt ( $this->ch, CURLOPT_HTTPGET, 1 );
					curl_setopt ( $this->ch, CURLOPT_URL, trim ( $url ) );
					$exec = curl_exec ( $this->ch );
					echo $x = curl_error ( $this->ch );
				}
				
				if (stristr ( $exec, '<option value="">- All categories -</option>' )) {
					echo '<br>categories found';
					preg_match_all ( "{>- All categories -</option>((.|\s)*?)</select>}", $exec, $matches, PREG_PATTERN_ORDER );
					
					$res = $matches [0];
					$cats = $res [0];
					
					// extracting single parent categories [<option value="1510">Betting Systems</option>]
					preg_match_all ( "{<option value=\"(.*?)\">(.*?)</option>}", $cats, $matches, PREG_PATTERN_ORDER );
					$paretcats_ids = $matches [1];
					$paretcats_names = $matches [2];
					
					// delete current records
					if (count ( $paretcats_names ) > 0) {
						$query = "delete from {$this->wp_prefix}automatic_categories ";
						$this->db->query ( $query );
					}
					
					// adding parent categories
					$i = 0;
					foreach ( $paretcats_ids as $parentcat_id ) {
						
						$parentcat_name = $paretcats_names [$i];
						
						// inserting cats
						$query = "insert into {$this->wp_prefix}automatic_categories (cat_id , cat_name) values ('$parentcat_id','$parentcat_name')";
						$this->db->query ( $query );
						$i ++;
					}
					
					echo '<br>Parent Categories added:' . $i;
					
					// extracting subcategories
					/*
					 * <option value="1265" parent="1253" path="Arts & Entertainment &raquo; Architecture"> Architecture </option>
					 */
					
					// echo $exec;
					// exit;
					preg_match_all ( "{<option value=\"(.*?)\"  parent=\"(.*?)\"(.|\s)*?>((.|\s)*?)</option>}", $exec, $matches, PREG_PATTERN_ORDER );
					$subcats_ids = $matches [1];
					$subcats_parents = $matches [2];
					$subcats_names = $matches [4];
					
					$i = 0;
					foreach ( $subcats_ids as $subcats_id ) {
						$subcats_names [$i] = trim ( $subcats_names [$i] );
						$subcats_parents [$i] = trim ( $subcats_parents [$i] );
						$query = "insert into {$this->wp_prefix}automatic_categories(cat_id,cat_parent,cat_name) values('$subcats_id','$subcats_parents[$i]','$subcats_names[$i]')";
						$this->db->query ( $query );
						$i ++;
					}
					
					echo '<br>Sub Categories added ' . $i;
					
					// print_r($matches);
					exit ();
					
					$res = $matches [2];
					$form = $res [0];
					
					preg_match_all ( "{<option value=\"(.*?)\"  parent=\"(.*?)\"}", $exec, $matches, PREG_PATTERN_ORDER );
					
					print_r ( $matches );
					
					// print_r($matches);
					exit ();
					$res = $matches [0];
					$cats = $res [0];
				}
			}
			
			/*
			 * ---* Proxy Frog Integration ---
			 */
			function alb_proxyfrog() {
				
				// get the current list
				$proxies = get_option ( 'alb_proxy_list' );
				
				// no proxies
				echo '<br>Need new valid proxies';
				
				if (function_exists ( 'proxyfrogfunc' )) {
					echo '<br>Getting New Proxy List from ProxyFrog.me';
					// Get
					$x = 'error';
					
					$ch = curl_init ();
					curl_setopt ( $ch, CURLOPT_HEADER, 0 );
					curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
					curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, 10 );
					curl_setopt ( $ch, CURLOPT_TIMEOUT, 20 );
					curl_setopt ( $ch, CURLOPT_REFERER, 'http://www.bing.com/' );
					curl_setopt ( $ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.8) Gecko/2009032609 Firefox/3.0.8' );
					curl_setopt ( $ch, CURLOPT_MAXREDIRS, 5 ); // Good leeway for redirections.
					curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, 0 ); // Many login forms redirect at least once.
					curl_setopt ( $ch, CURLOPT_COOKIEJAR, "cookie.txt" );
					
					// Get
					// license
					$paypal = get_option ( 'pf_license' );
					$paypal = urlencode ( $paypal );
					$url = "http://proxyfrog.me/proxyfrog/api.php?email=$paypal";
					curl_setopt ( $ch, CURLOPT_HTTPGET, 1 );
					curl_setopt ( $ch, CURLOPT_URL, trim ( $url ) );
					$exec = curl_exec ( $ch );
					
					// echo $exec;
					
					if (stristr ( $exec, ':' )) {
						update_option ( 'be_proxy_list', $exec );
						update_option ( 'alb_proxy_list', $exec );
						echo '<br>New Proxy List <b>Added successfully</b> ';
						$this->log ( 'ProxyFrog', "New Proxy list added from ProxyFrog" );
						return true;
					} else {
						$this->log ( 'ProxyFrog', $exec );
					}
				} else {
					
					return false;
				}
			} // end fun
			
			/*
			 * ---* Logging Function ---
			 */
			function log($type, $data) {
				// $now= date("F j, Y, g:i a");
				$now = date ( 'Y-m-d H:i:s' );
				$data = @addslashes ( $data );
				
				 
				$query = "INSERT INTO {$this->wp_prefix}automatic_log (action,date,data) values('$type','$now','$data')";
				
				 
				
				// echome$query;
				$this->db->query ( $query );
				
				$insert = $this->db->insert_id;
				
				$insert_below_100 = $insert -100 ;
				
				if($insert_below_100 > 0){
					//delete
					$query="delete from {$this->wp_prefix}automatic_log where id < $insert_below_100 and action not like '%Posted%'" ;
					$this->db->query($query);
				}
				
			}
			
			/**
			 * Function that checks if the current link is already posted 
			 * @param unknown $link
			 */
			function is_duplicate($link_url){
				
				$query = "SELECT post_id from {$this->wp_prefix}postmeta where meta_value='$link_url' ";
				$pres = $this->db->get_results ( $query );
				
				//double check again
				if(count ( $pres ) == 0 ){
					$pres = $this->db->get_results ( $query );
				}
				 
		
				$duplicate=false;
				if(count ( $pres ) == 0 ){
					$duplicate = false;
				}else{
					
					$duplicate = true;
					
		 
					foreach($pres as $prow){
						
						$ppid=$prow->post_id;
						$this->duplicate_id = $ppid;
						
						$pstatus = get_post_status($ppid);
							
						if($pstatus != 'trash') {
							break;
						}
					} 
					
				}
				
				// Check if completely deleted
				
				if( ! $duplicate){
				
					$md5 = md5($link_url);
					$query = "SELECT link_url from {$this->wp_prefix}automatic_links where link_url='$md5' ";
					$pres = $this->db->get_results ( $query );
					
					if ( count($pres) != 0){
						$duplicate = true;
						$this->duplicate_id = 'Deleted' ;
					}
					
				 
				}
				
				
 
				
				return $duplicate;
				
			}
		
			/**
			 * Function link exclude to execlude links
			 * @param unknown $camp_id
			 * @param unknown $source_link
			 */
			function link_execlude($camp_id,$source_link){
				update_post_meta($camp_id,'_execluded_links', get_post_meta($camp_id,'_execluded_links',1).','.$source_link );
			}
			
			/**
			 * Check if link is execluded or not i.e it didn't contain exact match keys or contins blocked keys
			 * @param unknown $camp_id
			 * @param unknown $link
			 */
			function is_execluded($camp_id,$link){
				
				  
				$execluded_links = get_post_meta($camp_id,'_execluded_links',1);
				
		 
				if(stristr(','.$execluded_links, $link )){
					return true;
				}else{
					return false;
				}
				
			}
			
			/**
			 * function cache_image 
			 * return local image src if found 
			 * return false if not cached 
			 */
			function is_cached($remote_img,$data_md5){
				
				//md5
				$md5=md5($remote_img);
				
				//query database for this image 
				
				$query="SELECT * FROM {$this->db->prefix}automatic_cached where img_hash='$md5' and img_data_hash='$data_md5' limit 1";
				
				 
				$rows=$this->db->get_results($query);
				
				if(count($rows) == 0 ) return false;
				$row=$rows[0];
				
				//hm we have cached image with previous same source let's compare 
				$local_src = $row->img_internal;
				
				//make sure current image have same data md5 right now otherwise delete
				//curl get
				curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
				curl_setopt($this->ch, CURLOPT_URL, trim($local_src));
			 	$exec=curl_exec($this->ch);
			 	
			 	if(md5($exec) == $data_md5) {
			 		
			 		$this->cached_file_path = $row->img_path;
			 		
			 		return $local_src;
			 	}else{
			 		
			 		//now the local image no more giving the same md5 may be deleted or changed delete the record
			 		$query="delete from {$this->db->prefix}automatic_cached where img_hash = '$md5' ";
			 		$this->db->query($query);
			 		
			 		return false;
			 	}
			 	
			 	 
				 	  
			}
			
			/**
			 * 
			 * @param unknown $remote_img
			 * @param unknown $local_img
			 * @param number $thumb_id
			 */
			
			function img_cached($remote_img,$local_img,$image_data_md5,$file_path  ){
				
				$md5= md5($remote_img);
				$query="insert into {$this->db->prefix}automatic_cached(img_external,img_internal,img_hash,img_data_hash,img_path) values ('$remote_img','$local_img','$md5','$image_data_md5','$file_path')";
				$this->db->query($query);
				
				 
			}
			
			/**
			 * deactivate keyword : set the reactivation time to one comig hour
			 * @param integer $camp_id
			 * @param string $keyword
			 */
			function deactivate_key($camp_id,$keyword){
				update_post_meta($camp_id, '_'.md5($keyword), time('now') + 60*60 );
			}
			
			/**
			 * is_deactivated: check if the current deactivated keyword is still deactivated or not 
			 * if yes it return false 
			 * if not deactivated return true
			 * @param integer $camp_id
			 * @param string $key
			 */
			function is_deactivated($camp_id,$keyword){
				
				//let's see if this keyword deactivated till date or not
				$keyword_key = '_'.md5($keyword) ;
				$deactivated_till = get_post_meta($camp_id,$keyword_key,1);
				if(trim($deactivated_till) == '') $deactivated_till = 1410020931;
				
				if(time('now') > $deactivated_till ){
					//time passed let's reactivate
					echo '<br>Keyword search reached end page lets sart from first page again ';
					return true;	
				}else{
						
					//still deactivated
					echo '<br>Calling source for this keyword is <strong>deactivated</strong> for one hour due to last time we called there were no more results to get we will reactivate it after '. number_format((    $deactivated_till - time('now') )  /60 , 2 )   . ' minutes. You can still <a class="wp_automatic_key_reactivate" data-id="'.$camp_id.'" data-key="'. $keyword_key . '" href="#">Reactivate Now.</a><span class="spinner_'.$keyword_key.'  spinner"></span>' ;
					return false;
				}
				
			}
			
			/**
			 * Function is_link_old check if the timestamp for the link is older than minimum
			 * @param unknown $camp_id
			 * @param unknown $link_timestamp
			 */
			function is_link_old($camp_id , $link_timestamp){
				
				if($this->debug) echo '<br>is_link_old Minimum:'.$this->minimum_post_timestamp . ' Current:'.$link_timestamp;
				
				if($this->minimum_post_timestamp_camp == $camp_id ){
					if($link_timestamp < $this->minimum_post_timestamp){
						return true;
					}else{
						return false;
					}
				}
			}
			
			/**
			 * function is_title_duplicate
			 * @param unknown $title
			 */
			function is_title_duplicate($title,$post_type){
				if( get_page_by_title( $title, 'OBJECT', $post_type )  ){
					
					return true;
					
				}else{
					return false;
				}
			}
			
			/*
			 * ---* validating ---
			 */
			function validate() {
				$paypal = get_option ( 'alb_license', '' );
				$active = get_option ( 'alb_license_active', '' );
				$link = 'http://wpplusone.com/trafficautomator/activate.php';
				
				// no license
				if (trim ( $paypal ) == '') {
					$this->log ( 'Error', 'License Required please visit settings and add the paypal email you used to purchase the product' );
					exit ();
				}
				
				// cehck validety
				if (trim ( $active ) != '1') {
					// first time activation
					// opening the page using curl
					$this->c->set ( CURLOPT_URL, trim ( "$link?email=$paypal" ) );
					$this->c->set ( CURLOPT_CONNECTTIMEOUT, 20 );
					$this->c->set ( CURLOPT_TIMEOUT, 50 );
					$this->c->set ( CURLOPT_HTTPGET, 1 );
					$ret = $this->c->execute ();
					$ret = trim ( $ret );
					// when no response
					if ($ret == '') {
						// service not available
						$this->log ( 'Error', 'Could not activate licence at this time may be our server is under maintenance now I will keep try and if the problem exists contact support' );
						exit ();
					} elseif ($ret == '0') {
						// not valid license
						$this->log ( 'Error', 'License is not valid please visit settings and use a valid license please, if you do\'t have a license consider to purchase <a href="http://wpsbox.com/buy">Here</a> and if you have just purchased just hold on our records will update after 10 minutes please be patient' );
						exit ();
					} elseif ($ret == '-1') {
						// Refunded
						$this->log ( 'Error', 'License is not valid a Refund may have been already issued for this license' );
						exit ();
					} elseif ($ret == '1') {
						// valid license
						update_option ( 'alb_license_active', '1' );
						// register last chek
						$date = date ( "m\-d\-y" );
						update_option ( 'alb_license_last', $date );
					} else {
						$this->log ( 'Error', 'License could not be validated at this time, our server may be under maintenance now will try the next cron' );
						exit ();
					}
				} else {
					// license is working without problem we should check again
					$date = date ( "m\-d\-y" );
					$last_check = get_option ( 'alb_license_last', $date );
					$offset = $this->dateDiff ( "-", $date, $last_check );
					if ($offset >= 1) {
						// echo 'checking license again';
						// check again
						// opening the page using curl
						$this->c->set ( CURLOPT_URL, trim ( "$link?email=$paypal" ) );
						$this->c->set ( CURLOPT_CONNECTTIMEOUT, 20 );
						$this->c->set ( CURLOPT_TIMEOUT, 50 );
						$this->c->set ( CURLOPT_HTTPGET, 1 );
						$ret = $this->c->execute ();
						$ret = trim ( $ret );
						// when no response
						if ($ret == '0') {
							// not valid license
							$this->log ( 'Error', 'License is not valid please visit settings and use a valid license please, if you do\'t have a license consider to purchase <a href="http://wpsbox.com/buy">Here</a>' );
							update_option ( 'alb_license_active', '' );
							exit ();
						} elseif ($ret == '-1') {
							// Refunded
							$this->log ( 'Error', 'License is not valid a Refund may have been already issued for this license' );
							update_option ( 'alb_license_active', '' );
							exit ();
						} elseif ($ret == '1') {
							// valid license
							update_option ( 'alb_license_active', '1' );
							// register last chek
							$date = date ( "m\-d\-y" );
							update_option ( 'alb_license_last', $date );
						}
					}
				}
				
				return true;
			}
			
			/*
			 * ---* Date Difference return days between two dates ---
			 */
			function dateDiff($dformat, $endDate, $beginDate) {
				$date_parts1 = explode ( $dformat, $beginDate );
				$date_parts2 = explode ( $dformat, $endDate );
				$start_date = gregoriantojd ( $date_parts1 [0], $date_parts1 [1], $date_parts1 [2] );
				$end_date = gregoriantojd ( $date_parts2 [0], $date_parts2 [1], $date_parts2 [2] );
				return $end_date - $start_date;
			}
			
			/*
			 * ---* Download File ---
			 */
			function downloadfile($link) {
				$downloader = $this->plugin_url . 'downloader.php';
				// $downloader='http://localhost/php/wpsbox_aals/downloader.php';
				$link = str_replace ( 'http', 'httpz', $link );
				
				$enc = urlencode ( $link );
				// $return=file_get_contents($downloader.'?link='.$enc);
				// echo $return ;
				
				if (stristr ( $return, 'error' )) {
					echo '<br>An Error downloading the <b>damn file</b> :';
					echo ' <i><small>' . $return . '</small></i>';
					
					return false;
				}
				return true;
			}
			
			/*
			 * ---* Solve captcha function ---
			 */
			function solvecap($url) {
				$decap_user = get_option ( 'alb_de_u' );
				$decap_pass = get_option ( 'alb_de_p' );
				
				// if decap not registered return false
				if (trim ( $decap_user ) == '' || trim ( $decap_pass ) == '') {
					echo '<br>decaptcher.com <b>account needed</b>';
					$this->log ( 'Error', 'Capatcha Met at ' . $proxy . ' , Decapatcher Account needed please register one at decapatcher.com , add balance to it then enter login details at settings tab ' );
					return false;
				}
				
				// curl ini
				$ch = curl_init ();
				curl_setopt ( $ch, CURLOPT_HEADER, 0 );
				curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
				curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, 10 );
				curl_setopt ( $ch, CURLOPT_TIMEOUT, 20 );
				curl_setopt ( $ch, CURLOPT_REFERER, 'http://www.bing.com/' );
				curl_setopt ( $ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.8) Gecko/2009032609 Firefox/3.0.8' );
				curl_setopt ( $ch, CURLOPT_MAXREDIRS, 5 ); // Good leeway for redirections.
				curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, 1 ); // Many login forms redirect at least once.
				curl_setopt ( $ch, CURLOPT_COOKIEJAR, "cookie.txt" );
				curl_setopt ( $ch, CURLOPT_URL, trim ( $url ) );
				curl_setopt ( $ch, CURLOPT_HEADER, 0 );
				$img = curl_exec ( $ch );
				if (trim ( $img ) == '')
					return false;
				if (curl_error ( $ch ) != '') {
					echo '<br>Image fetched with error:' . curl_error ( $ch ) . '<br>';
					return false;
				}
				
				// file_put_contents('files/cap.jpg',$img);
				
				// positng image to capatcher to get the decapatched version
				curl_setopt ( $ch, CURLOPT_VERBOSE, 0 );
				curl_setopt ( $ch, CURLOPT_URL, 'http://poster.decaptcher.com' );
				curl_setopt ( $ch, CURLOPT_POST, true );
				
				$decap_acc = '1169';
				
				$post = array (
						"pict" => "@files/cap.jpg",
						"function" => "picture2",
						"username" => $decap_user,
						"password" => $decap_pass,
						"pict_to" => "0",
						"pict_type" => $decap_acc 
				);
				curl_setopt ( $ch, CURLOPT_POSTFIELDS, $post );
				if (curl_error ( $ch ) != '') {
					echo '<br>Captacha Posted with error:' . curl_error ( $ch ) . '<br>';
					return false;
				}
				
				$decap = curl_exec ( $ch );
				echo '<br>Decap returned:' . $decap;
				// check if decapatcher returned an error -
				if (stristr ( $decap, '-' ) || trim ( $decap ) == '') {
					echo '<br>Decapatcher returned an <b>error</b> ' . $decap;
					$this->log ( 'Error', 'Decapatcher Account Error Please check login details and suffecient balance' );
					return false;
				}
				
				if (trim ( $decap ) == '')
					return false;
				$decaps = explode ( '|', $decap );
				$decap = $decaps [5];
				if (trim ( $decap ) == '')
					return false;
				echo '<br>Decap Solution:' . $decap;
				return $decap;
			}
			
			/*
			 * ---* Trackback function using wp modification ---
			 */
			function trackback($trackback_url, $author, $ttl, $excerpt, $link) {
				$options = array ();
				$options ['timeout'] = 4;
				$options ['body'] = array (
						'title' => $ttl,
						'url' => $link,
						'blog_name' => $author,
						'excerpt' => $excerpt 
				);
				
				$response = wp_remote_post ( $trackback_url, $options );
				
				if (is_wp_error ( $response )) {
					echo '<br>Trackback Error';
					return;
				} else {
					echo '<br>No Track back error';
				}
			}
			
			 
			/*
			 * function get_time_difference: get the time difference in minutes.
			* @start: time stamp
			* @end: time stamp
			*/
			
			function get_time_difference( $start, $end )
			{
			
				$uts['start']      =     $start ;
				$uts['end']        =      $end ;
			
			
			
				if( $uts['start']!==-1 && $uts['end']!==-1 )
				{
					if( $uts['end'] >= $uts['start'] )
					{
						$diff    =    $uts['end'] - $uts['start'];
			
						return round($diff/60,0);
			
					}
			
				}
			}
			
			function truncateHtml($text, $length = 100, $ending = '...', $exact = false, $considerHtml = true) {
				if ($considerHtml) {
					// if the plain text is shorter than the maximum length, return the whole text
					if (strlen(preg_replace('/<.*?>/', '', $text)) <= $length) {
						return $text;
					}
					// splits all html-tags to scanable lines
					preg_match_all('/(<.+?>)?([^<>]*)/s', $text, $lines, PREG_SET_ORDER);
					$total_length = strlen($ending);
					$open_tags = array();
					$truncate = '';
					foreach ($lines as $line_matchings) {
						// if there is any html-tag in this line, handle it and add it (uncounted) to the output
						if (!empty($line_matchings[1])) {
							// if it's an "empty element" with or without xhtml-conform closing slash
							if (preg_match('/^<(\s*.+?\/\s*|\s*(img|br|input|hr|area|base|basefont|col|frame|isindex|link|meta|param)(\s.+?)?)>$/is', $line_matchings[1])) {
								// do nothing
								// if tag is a closing tag
							} else if (preg_match('/^<\s*\/([^\s]+?)\s*>$/s', $line_matchings[1], $tag_matchings)) {
								// delete tag from $open_tags list
								$pos = array_search($tag_matchings[1], $open_tags);
								if ($pos !== false) {
									unset($open_tags[$pos]);
								}
								// if tag is an opening tag
							} else if (preg_match('/^<\s*([^\s>!]+).*?>$/s', $line_matchings[1], $tag_matchings)) {
								// add tag to the beginning of $open_tags list
								array_unshift($open_tags, strtolower($tag_matchings[1]));
							}
							// add html-tag to $truncate'd text
							$truncate .= $line_matchings[1];
						}
						// calculate the length of the plain text part of the line; handle entities as one character
						$content_length = strlen(preg_replace('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', ' ', $line_matchings[2]));
						if ($total_length+$content_length> $length) {
							// the number of characters which are left
							$left = $length - $total_length;
							$entities_length = 0;
							// search for html entities
							if (preg_match_all('/&[0-9a-z]{2,8};|&#[0-9]{1,7};|[0-9a-f]{1,6};/i', $line_matchings[2], $entities, PREG_OFFSET_CAPTURE)) {
								// calculate the real length of all entities in the legal range
								foreach ($entities[0] as $entity) {
									if ($entity[1]+1-$entities_length <= $left) {
										$left--;
										$entities_length += strlen($entity[0]);
									} else {
										// no more characters left
										break;
									}
								}
							}
							$truncate .= substr($line_matchings[2], 0, $left+$entities_length);
							// maximum lenght is reached, so get off the loop
							break;
						} else {
							$truncate .= $line_matchings[2];
							$total_length += $content_length;
						}
						// if the maximum length is reached, get off the loop
						if($total_length>= $length) {
							break;
						}
					}
				} else {
					if (strlen($text) <= $length) {
						return $text;
					} else {
						$truncate = substr($text, 0, $length - strlen($ending));
					}
				}
				// if the words shouldn't be cut in the middle...
				if (!$exact) {
					// ...search the last occurance of a space...
					$spacepos = strrpos($truncate, ' ');
					if (isset($spacepos)) {
						// ...and cut the text in this position
						$truncate = substr($truncate, 0, $spacepos);
					}
				}
				// add the defined ending to the text
				$truncate .= $ending;
				if($considerHtml) {
					// close all unclosed html-tags
					foreach ($open_tags as $tag) {
						$truncate .= '</' . $tag . '>';
					}
				}
				return $truncate;
			}//end function
			
			
			/**
			 * function: curl with follocation that will get url if openbasedir is set or safe mode enabled
			 * @param unknown $ch
			 * @return mixed
			 */
			
			function curl_exec_follow( &$ch){
			
				  
				$max_redir = 3;
			
				for ($i=0;$i<$max_redir;$i++){
			
					$exec=curl_exec($ch);
				 
					 
					$info = curl_getinfo($ch);
			 
					
					if($info['http_code'] == 301 ||  $info['http_code'] == 302){
						
						//if there is no reddirect_url
						if(trim($info['redirect_url']) == ''){
							$info['redirect_url']= curl_getinfo($ch, CURLINFO_REDIRECT_URL);
							
							//if php is below 5.3.7 and there is no redirect_url option
							if(trim($info['redirect_url']) == '' ){
								
									if(stristr($exec, 'Location:')){
										preg_match( '{Location:(.*)}' , $exec, $loc_matches);
										$redirect_url = trim($loc_matches[1]);
								
										if(trim($redirect_url) !=  ''){
											$info['redirect_url'] = $redirect_url;
										}
									}
								 
								
							}
							
						}
						
						curl_setopt($ch, CURLOPT_HTTPGET, 1);
						curl_setopt($ch, CURLOPT_URL, trim($info['redirect_url']));
						
						$exec=curl_exec($ch);
							
					}else{
							
						//no redirect just return
						break;
							
					}
			
			
				}
			
				return $exec;
			
			}
			
			/**
			 * function curl_file_exists: check existence of a file
			 * @param unknown $url
			 * @return boolean
			 */
			function curl_file_exists($url){
			
				//curl get
			
				$x='error';
				curl_setopt($this->ch, CURLOPT_HTTPGET, 1);
				curl_setopt($this->ch, CURLOPT_URL, trim($url));
				curl_setopt($this->ch, CURLOPT_REFERER, $url);
				//curl_setopt($this->ch, CURLOPT_NOBODY, true);
			
				$exec=curl_exec($this->ch);
				$x=curl_error($this->ch);
			
				$httpCode = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
			 
				//curl_setopt($this->ch, CURLOPT_NOBODY, false);
			
			 	
				if($httpCode == '200' || $httpCode == '302') return true;
			
				return false;
			}
			
			//function to get user id and create it if not exists
			function get_user_id_by_display_name( $display_name ) {
				 
				//trim
				$display_name = trim($display_name);
				
				
				//check user existence 
				if ( ! $user = $this->db->get_row( $this->db->prepare(
						"SELECT `ID` FROM {$this->db->users} WHERE `display_name` = %s", $display_name
				) ) ){
					
					//replace spaces
					$login_name = str_replace(' ', '_', $display_name);
					
					
					//no user with this name let's create it and return the id
					$userdata['display_name'] = $display_name;
					$userdata['user_login'] = $display_name; 
					
					$user_id = wp_insert_user( $userdata );
					
					
					if( !is_wp_error($user_id) ) {
						echo '<br>New user created:'.$login_name;
						return $user_id;
					}else {
						return false;
					}
					 
					return false;
					 
				}
					
			
				return $user->ID;
			}
			
			//remove emoji from instagram 
			 function removeEmoji($text) {
			
				$clean_text = "";
			
				// Match Emoticons
				$regexEmoticons = '/[\x{1F600}-\x{1F64F}]/u';
				$clean_text = preg_replace($regexEmoticons, '', $text);
			
				// Match Miscellaneous Symbols and Pictographs
				$regexSymbols = '/[\x{1F300}-\x{1F5FF}]/u';
				$clean_text = preg_replace($regexSymbols, '', $clean_text);
			
				// Match Transport And Map Symbols
				$regexTransport = '/[\x{1F680}-\x{1F6FF}]/u';
				$clean_text = preg_replace($regexTransport, '', $clean_text);
			
				// Match Miscellaneous Symbols
				$regexMisc = '/[\x{2600}-\x{26FF}]/u';
				$clean_text = preg_replace($regexMisc, '', $clean_text);
			
				// Match Dingbats
				$regexDingbats = '/[\x{2700}-\x{27BF}]/u';
				$clean_text = preg_replace($regexDingbats, '', $clean_text);
			
				return $clean_text;
			}

			//function for hyperlinking
			function hyperlink_this($text){
				
				return preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$0</a>', $text);
				
			}
			
			//function for stripping inline urls
			function strip_urls($content){
			
				return preg_replace('{http[s]?://[^\s]*}', '', $content);
			
			}
			
			//fix invalid uلtf chars
			function fix_utf8($string){
				
			 
				//check if wrong utf8
				if ( 1 === @preg_match( '/^./us', $string ) ) {
			
					return $string;
				}else{
					echo '<br>Fixing invalid utf8 text...'  ;
					return iconv( 'utf-8', 'utf-8//IGNORE', $string );
			
				}
			
			}
			
			function cleanthetitle($title) {
				$title = str_replace('nospin', '', $title);
				$title = str_replace(' ', '-', $title); // Replaces all spaces with hyphens.
				$title = preg_replace('/[^A-Za-z0-9\-]/', '', $title); // Removes special chars.
			
				return preg_replace('/-+/', '-', $title); // Replaces multiple hyphens with single one.
			}
			
			//is_enlish: checks if the text is english requires mb_string module
			function is_english ($string){
				
				if( !  function_exists('mb_strlen') ){
					
					echo '<br>Will skip checking if english as mbstring module must be installed ';
					
					return true;
				}
				
				$string = str_replace(array('”','“','’','‘','’'),'',$string) ;
				
				
				if(strlen($string) != mb_strlen($string, 'utf-8'))
				{
					return false;
				}
				else {
					return true;
				}
				
				
			}
			
			/**
			* Count chars on text using mb_ module and if not exists it count it using strlen
			* @param unknown $text
			*/
			function chars_count(&$text){
			
				if(function_exists('mb_strlen')){
					return mb_strlen($text);
				}else{
					return strlen($text);
				}
			
			}
				
			 
			
		} // End
		
?>